(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"InteractiveReoresentationBakapaim_atlas_1", frames: [[0,1129,1229,240],[0,1371,1229,240],[0,1613,1229,240],[0,0,2018,1127]]},
		{name:"InteractiveReoresentationBakapaim_atlas_2", frames: [[0,1694,943,180],[945,1694,943,180],[0,0,1229,240],[0,242,1229,240],[0,484,1229,240],[0,726,1229,240],[0,968,1229,240],[0,1210,1229,240],[0,1452,1229,240]]},
		{name:"InteractiveReoresentationBakapaim_atlas_3", frames: [[0,182,943,177],[945,358,943,177],[0,361,943,177],[0,0,943,180],[945,0,953,177],[945,537,943,177],[945,179,953,177],[0,540,943,177],[0,719,540,149],[1809,1023,231,253],[603,1182,273,192],[542,719,362,214],[0,1339,270,208],[1620,716,273,305],[1357,1283,215,227],[1574,1361,214,226],[603,1376,222,231],[0,1106,310,231],[272,1424,223,229],[1056,1820,199,204],[312,1180,289,242],[933,1076,200,267],[945,716,327,358],[700,1760,176,235],[1135,1283,220,237],[0,1549,220,232],[0,870,329,234],[1577,1023,230,336],[1274,1009,301,272],[1809,1278,221,262],[1759,1742,185,234],[0,1783,193,243],[643,935,288,245],[1357,1512,205,223],[1895,358,151,342],[827,1584,248,174],[331,935,310,243],[388,1820,201,209],[1257,1820,199,204],[1458,1820,199,204],[878,1760,176,235],[878,1345,220,237],[1100,1522,185,234],[1564,1589,193,229],[195,1783,191,227],[497,1609,201,209],[1790,1542,236,198],[1274,716,344,291]]},
		{name:"InteractiveReoresentationBakapaim_atlas_4", frames: [[401,691,383,94],[505,645,77,39],[1986,539,54,54],[0,726,383,94],[1152,780,383,94],[465,1882,91,32],[1994,938,54,54],[1537,780,383,94],[385,787,383,94],[1067,1837,82,49],[1994,994,54,54],[0,822,383,94],[770,876,383,94],[1155,876,383,94],[1540,876,383,94],[1986,473,51,64],[1925,828,115,108],[1092,386,24,24],[591,1654,274,79],[0,1931,2020,2],[213,1126,115,108],[147,482,24,24],[1811,1706,228,83],[0,1935,2020,2],[1886,1160,115,108],[1567,514,24,24],[1191,1650,249,79],[0,1939,2020,2],[472,1772,115,108],[1567,540,24,24],[1563,1706,246,77],[0,1943,2020,2],[1563,1785,115,108],[1714,583,24,24],[1191,1731,233,78],[0,1947,2020,2],[1680,1785,115,108],[1740,583,24,24],[197,1662,247,78],[0,1951,2020,2],[1797,1791,115,108],[1766,583,24,24],[1571,1170,313,81],[0,1955,2020,2],[1914,1791,115,108],[538,591,24,24],[964,784,183,77],[0,1959,2020,2],[1191,1811,115,108],[538,617,24,24],[529,1097,202,78],[0,1963,2020,2],[1308,1811,115,108],[345,918,24,24],[280,1772,190,78],[0,1967,2020,2],[0,1742,652,28],[1042,1285,995,33],[1994,1106,49,49],[1208,1554,240,94],[1685,1610,240,94],[589,1772,63,92],[1002,1837,63,92],[965,1523,72,105],[867,1653,71,104],[1994,1050,54,54],[1255,1320,131,232],[1929,612,114,214],[1388,1320,131,232],[1334,414,231,162],[1927,1476,111,197],[654,1735,97,181],[965,1638,111,197],[1693,1470,195,138],[197,1523,195,137],[1554,1895,67,34],[520,180,31,12],[1450,1554,54,54],[199,180,227,170],[1061,211,221,173],[199,0,223,178],[428,202,224,172],[1284,344,139,36],[1986,411,56,60],[0,420,155,60],[1143,386,189,199],[585,491,188,198],[849,0,195,203],[401,591,135,52],[1498,1841,54,54],[965,491,168,51],[0,1663,148,45],[353,1852,54,54],[852,1759,81,51],[1859,196,180,213],[1630,0,199,194],[1425,1841,71,45],[409,1852,54,54],[171,918,172,206],[726,379,145,34],[589,1866,54,54],[168,1971,47,59],[1527,583,185,195],[1425,1888,63,40],[1521,1494,162,146],[0,1971,54,54],[213,1236,89,42],[0,1772,138,126],[852,1884,76,37],[56,1971,54,54],[1795,368,32,39],[575,883,169,212],[920,972,169,209],[0,204,179,214],[1614,368,179,213],[1069,544,69,39],[112,1971,54,54],[1563,1642,119,48],[0,1132,211,147],[965,544,102,41],[1078,1638,111,197],[753,1735,97,181],[1450,1642,111,197],[0,1523,195,138],[394,1523,195,137],[1623,1895,67,34],[1630,196,227,170],[181,352,221,173],[424,0,223,178],[1567,566,26,11],[654,205,224,172],[585,379,139,36],[1795,411,189,199],[775,491,188,198],[1046,0,195,203],[446,1662,135,52],[0,0,197,202],[852,1837,148,45],[1432,199,180,213],[1831,0,199,194],[280,1852,71,45],[746,972,172,206],[0,482,145,34],[0,527,187,197],[1567,414,40,51],[965,587,185,195],[649,0,198,200],[1432,0,196,197],[217,1971,63,40],[140,1772,138,126],[1067,1888,76,37],[0,918,169,212],[1091,972,169,209],[880,205,179,214],[404,376,179,213],[930,1884,69,39],[1714,612,213,150],[1042,1320,211,147],[401,645,102,41],[585,421,556,68],[1890,1320,155,154],[1042,1469,164,167],[1450,972,179,192],[345,1076,182,187],[529,1183,1040,32],[529,1217,1040,32],[282,1971,49,49],[529,1251,1040,32],[0,1285,1040,32],[0,1319,1040,32],[0,1353,1040,32],[0,1387,1040,32],[0,1421,1040,32],[0,1455,1040,32],[0,1489,1040,32],[645,187,2,3],[278,715,22,8],[1425,211,5,30],[1127,205,6,4],[1290,382,3,2],[1598,467,11,23],[1425,243,5,6],[1425,350,3,6],[181,204,12,36],[2032,145,16,29],[1425,301,4,5],[1427,382,3,5],[1614,293,14,25],[1624,246,4,6],[1425,308,4,5],[645,180,2,5],[1593,532,16,17],[195,218,2,4],[181,334,14,15],[1624,254,4,6],[1425,315,4,5],[195,242,2,3],[614,192,32,6],[2032,176,4,18],[1626,335,2,2],[520,194,28,5],[1167,205,7,3],[1199,205,6,3],[195,224,2,4],[654,202,33,1],[195,247,2,3],[689,202,29,1],[1284,211,139,131],[1135,205,6,4],[873,379,5,3],[1425,322,4,5],[614,180,29,10],[1231,205,4,4],[229,704,26,9],[1693,1320,190,148],[1176,205,7,3],[1207,205,6,3],[1425,358,3,6],[345,1044,25,21],[195,204,2,5],[428,180,22,18],[786,691,176,178],[1425,251,5,5],[1425,329,4,5],[157,453,14,21],[1598,492,13,19],[1521,1320,170,172],[1152,587,179,181],[1237,205,4,4],[2041,391,4,3],[2041,262,7,32],[173,442,6,28],[189,527,210,175],[173,502,6,5],[1185,205,5,4],[1425,274,3,7],[2041,362,3,6],[305,704,20,11],[1567,467,29,45],[1595,551,11,23],[1925,938,25,23],[169,420,10,20],[1749,764,17,9],[1614,320,10,31],[1614,263,14,28],[2032,73,16,34],[1215,205,6,3],[1624,228,3,16],[1626,339,2,2],[1829,368,24,38],[1284,382,4,2],[1295,382,3,2],[404,352,20,22],[1300,382,3,2],[1425,258,4,6],[1425,336,4,5],[1425,283,3,7],[1425,366,3,6],[195,252,2,3],[2039,473,9,19],[1624,199,4,27],[591,1523,186,129],[1714,764,15,12],[553,180,19,18],[1626,343,2,2],[2043,0,5,71],[2032,109,16,34],[1952,938,25,23],[1593,514,17,16],[1614,353,13,10],[157,420,10,31],[564,608,11,23],[1143,205,6,4],[1192,205,5,4],[1118,386,20,22],[195,257,2,3],[1092,412,19,7],[1334,578,191,192],[181,280,13,28],[257,704,19,12],[189,704,23,11],[574,180,18,19],[195,262,2,3],[2041,176,5,84],[476,180,20,19],[229,715,20,9],[1731,764,16,11],[1151,205,6,4],[873,384,5,3],[2032,0,9,71],[195,211,2,5],[2016,595,25,11],[1334,382,29,28],[1061,205,33,2],[594,180,18,19],[195,230,2,4],[345,944,25,23],[1096,205,29,2],[1118,410,21,9],[385,883,188,191],[1305,382,3,2],[1310,382,3,2],[1425,343,4,5],[147,508,18,16],[1365,382,29,28],[1986,595,28,10],[1614,199,8,62],[2041,378,4,4],[498,180,20,19],[278,704,25,9],[368,704,15,13],[1808,972,184,186],[1159,205,6,4],[1223,205,6,3],[195,267,2,3],[327,704,21,10],[345,994,24,23],[195,272,2,3],[2003,1157,25,21],[345,969,25,23],[452,180,22,18],[564,633,18,9],[2041,384,3,5],[195,236,2,4],[873,389,3,5],[564,591,18,15],[1396,382,29,28],[181,310,15,22],[1427,389,3,4],[2039,494,9,19],[214,704,13,19],[350,704,16,13],[1631,972,175,196],[1425,292,3,7],[2041,370,3,6],[779,1523,184,128],[1427,395,3,4],[345,1019,24,23],[2041,296,7,32],[1626,320,2,3],[173,472,6,28],[1262,972,186,186],[1425,266,4,6],[1425,374,3,6],[1243,0,187,209],[1626,325,2,3],[181,242,12,36],[1061,386,29,28],[2041,330,7,30],[1626,330,2,3],[1135,491,6,26]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_231 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_230 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_229 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_227 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_226 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_225 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_224 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_222 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_221 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_220 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_219 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_228 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_217 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_216 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_215 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_214 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_213 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_212 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_211 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_210 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_209 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_208 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_207 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_206 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_205 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_204 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_203 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_202 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_201 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_200 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_199 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_198 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_197 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_196 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_195 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_194 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_193 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_192 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_191 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_190 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_189 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_188 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_187 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_186 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_185 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_184 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_183 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_182 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_181 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_180 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_179 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_178 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_177 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_176 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_175 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_174 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_173 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_172 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_171 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_170 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_169 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_168 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_167 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_166 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_165 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_164 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_163 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_162 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_161 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_160 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_159 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_158 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_157 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_156 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_155 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_154 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_153 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_152 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_151 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_150 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_149 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_148 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_147 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_146 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_145 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_144 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_143 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_142 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_141 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_140 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_139 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_138 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_137 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_136 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_135 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_134 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_133 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_132 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_131 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_130 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_129 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_128 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_127 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_126 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_125 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_124 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_119 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_65 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_121 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.Group_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.Group_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(161);
}).prototype = p = new cjs.Sprite();



(lib.Group_3_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(162);
}).prototype = p = new cjs.Sprite();



(lib.Group_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(163);
}).prototype = p = new cjs.Sprite();



(lib.Group_8 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_3"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.Image_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(164);
}).prototype = p = new cjs.Sprite();



(lib.Image_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(165);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(166);
}).prototype = p = new cjs.Sprite();



(lib.Image_10 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(167);
}).prototype = p = new cjs.Sprite();



(lib.Image_12 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(168);
}).prototype = p = new cjs.Sprite();



(lib.Image_14 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(169);
}).prototype = p = new cjs.Sprite();



(lib.Image_16 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(170);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(171);
}).prototype = p = new cjs.Sprite();



(lib.Image_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(172);
}).prototype = p = new cjs.Sprite();



(lib.Image_6 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(173);
}).prototype = p = new cjs.Sprite();



(lib.Image_8 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(174);
}).prototype = p = new cjs.Sprite();



(lib.Path = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(175);
}).prototype = p = new cjs.Sprite();



(lib.Path_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(176);
}).prototype = p = new cjs.Sprite();



(lib.Path_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(177);
}).prototype = p = new cjs.Sprite();



(lib.Path_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(178);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(179);
}).prototype = p = new cjs.Sprite();



(lib.Path_10 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(180);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(181);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(182);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(183);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(184);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(185);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(186);
}).prototype = p = new cjs.Sprite();



(lib.Path_10_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(187);
}).prototype = p = new cjs.Sprite();



(lib.Path_11 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(188);
}).prototype = p = new cjs.Sprite();



(lib.Path_11_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(189);
}).prototype = p = new cjs.Sprite();



(lib.Path_11_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(190);
}).prototype = p = new cjs.Sprite();



(lib.Path_11_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(191);
}).prototype = p = new cjs.Sprite();



(lib.Path_11_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(192);
}).prototype = p = new cjs.Sprite();



(lib.Path_11_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(193);
}).prototype = p = new cjs.Sprite();



(lib.Path_12 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(194);
}).prototype = p = new cjs.Sprite();



(lib.Path_12_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(195);
}).prototype = p = new cjs.Sprite();



(lib.Path_12_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(196);
}).prototype = p = new cjs.Sprite();



(lib.Path_12_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(197);
}).prototype = p = new cjs.Sprite();



(lib.Path_12_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(198);
}).prototype = p = new cjs.Sprite();



(lib.Path_12_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(199);
}).prototype = p = new cjs.Sprite();



(lib.Path_12_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(200);
}).prototype = p = new cjs.Sprite();



(lib.Path_13 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(201);
}).prototype = p = new cjs.Sprite();



(lib.Path_13_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(202);
}).prototype = p = new cjs.Sprite();



(lib.Path_13_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(203);
}).prototype = p = new cjs.Sprite();



(lib.Path_13_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(204);
}).prototype = p = new cjs.Sprite();



(lib.Path_13_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(205);
}).prototype = p = new cjs.Sprite();



(lib.Path_13_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(206);
}).prototype = p = new cjs.Sprite();



(lib.Path_14 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(207);
}).prototype = p = new cjs.Sprite();



(lib.Path_14_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(208);
}).prototype = p = new cjs.Sprite();



(lib.Path_14_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(209);
}).prototype = p = new cjs.Sprite();



(lib.Path_14_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(210);
}).prototype = p = new cjs.Sprite();



(lib.Path_14_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(211);
}).prototype = p = new cjs.Sprite();



(lib.Path_14_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(212);
}).prototype = p = new cjs.Sprite();



(lib.Path_14_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(213);
}).prototype = p = new cjs.Sprite();



(lib.Path_15 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(214);
}).prototype = p = new cjs.Sprite();



(lib.Path_15_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(215);
}).prototype = p = new cjs.Sprite();



(lib.Path_15_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(216);
}).prototype = p = new cjs.Sprite();



(lib.Path_15_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(217);
}).prototype = p = new cjs.Sprite();



(lib.Path_15_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(218);
}).prototype = p = new cjs.Sprite();



(lib.Path_15_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(219);
}).prototype = p = new cjs.Sprite();



(lib.Path_15_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(220);
}).prototype = p = new cjs.Sprite();



(lib.Path_16 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(221);
}).prototype = p = new cjs.Sprite();



(lib.Path_16_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(222);
}).prototype = p = new cjs.Sprite();



(lib.Path_16_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(223);
}).prototype = p = new cjs.Sprite();



(lib.Path_16_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(224);
}).prototype = p = new cjs.Sprite();



(lib.Path_16_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(225);
}).prototype = p = new cjs.Sprite();



(lib.Path_17 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(226);
}).prototype = p = new cjs.Sprite();



(lib.Path_17_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(227);
}).prototype = p = new cjs.Sprite();



(lib.Path_17_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(228);
}).prototype = p = new cjs.Sprite();



(lib.Path_17_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(229);
}).prototype = p = new cjs.Sprite();



(lib.Path_17_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(230);
}).prototype = p = new cjs.Sprite();



(lib.Path_17_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(231);
}).prototype = p = new cjs.Sprite();



(lib.Path_18 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(232);
}).prototype = p = new cjs.Sprite();



(lib.Path_18_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(233);
}).prototype = p = new cjs.Sprite();



(lib.Path_18_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(234);
}).prototype = p = new cjs.Sprite();



(lib.Path_19 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(235);
}).prototype = p = new cjs.Sprite();



(lib.Path_19_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(236);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(237);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(238);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(239);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_11 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(240);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_13 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(241);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_15 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(242);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_17 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(243);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_19 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(244);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(245);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(246);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(247);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(248);
}).prototype = p = new cjs.Sprite();



(lib.Path_1_9 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(249);
}).prototype = p = new cjs.Sprite();



(lib.Path_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(250);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(251);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(252);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(253);
}).prototype = p = new cjs.Sprite();



(lib.Path_20 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(254);
}).prototype = p = new cjs.Sprite();



(lib.Path_20_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(255);
}).prototype = p = new cjs.Sprite();



(lib.Path_21 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(256);
}).prototype = p = new cjs.Sprite();



(lib.Path_21_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(257);
}).prototype = p = new cjs.Sprite();



(lib.Path_24 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(258);
}).prototype = p = new cjs.Sprite();



(lib.Path_25 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(259);
}).prototype = p = new cjs.Sprite();



(lib.Path_27 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(260);
}).prototype = p = new cjs.Sprite();



(lib.Path_29 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(261);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(262);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(263);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(264);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_11 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(265);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(266);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_3_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(267);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_5 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(268);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(269);
}).prototype = p = new cjs.Sprite();



(lib.Path_2_9 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(270);
}).prototype = p = new cjs.Sprite();



(lib.Path_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(271);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(272);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(273);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(274);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(275);
}).prototype = p = new cjs.Sprite();



(lib.Path_30 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(276);
}).prototype = p = new cjs.Sprite();



(lib.Path_31 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(277);
}).prototype = p = new cjs.Sprite();



(lib.Path_33 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(278);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(279);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(280);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(281);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(282);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(283);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_3_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(284);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_5 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(285);
}).prototype = p = new cjs.Sprite();



(lib.Path_3_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(286);
}).prototype = p = new cjs.Sprite();



(lib.Path_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(287);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(288);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(289);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(290);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(291);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(292);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(293);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_0_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(294);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(295);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_3_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(296);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_5 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(297);
}).prototype = p = new cjs.Sprite();



(lib.Path_4_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(298);
}).prototype = p = new cjs.Sprite();



(lib.Path_5 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(299);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(300);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(301);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(302);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(303);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(304);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(305);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_0_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(306);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(307);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_3_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(308);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_5 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(309);
}).prototype = p = new cjs.Sprite();



(lib.Path_5_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(310);
}).prototype = p = new cjs.Sprite();



(lib.Path_6 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(311);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(312);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(313);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(314);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(315);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(316);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(317);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(318);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(319);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(320);
}).prototype = p = new cjs.Sprite();



(lib.Path_6_6 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(321);
}).prototype = p = new cjs.Sprite();



(lib.Path_7 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(322);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(323);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(324);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(325);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(326);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(327);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_0_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(328);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_1_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(329);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(330);
}).prototype = p = new cjs.Sprite();



(lib.Path_7_5 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(331);
}).prototype = p = new cjs.Sprite();



(lib.Path_8 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(332);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(333);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(334);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(335);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(336);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(337);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(338);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(339);
}).prototype = p = new cjs.Sprite();



(lib.Path_8_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(340);
}).prototype = p = new cjs.Sprite();



(lib.Path_9 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(341);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(342);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(343);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(344);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_4 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(345);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_0 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(346);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_0_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(347);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_0_2 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(348);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_0_3 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(349);
}).prototype = p = new cjs.Sprite();



(lib.Path_9_2_1 = function() {
	this.initialize(ss["InteractiveReoresentationBakapaim_atlas_4"]);
	this.gotoAndStop(350);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.instructions = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {normal:0,click:1};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_152();
	this.instance.setTransform(-248.75,-8.15,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_153();
	this.instance_1.setTransform(-162.95,-8.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-248.7,-8.1,497.5,16.5);


(lib.Path_32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_33();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_32, new cjs.Rectangle(0,0,13,28), null);


(lib.Path_31_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(0.2).p("AHDkFQgrgshLgTQhFgShKAHQhGAHhHAeQg8AahTA1QhmBDg0AlQhcBAgzAxQiNCGBMBqQAsA3BMAaQBFAXBIgGQBCgFBFgfQAygWBcg5QDMiGBphuQCTidhXhRg");
	this.shape.setTransform(48.5009,33.8507);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D1D1B").s().p("AlQE/QhMgagsg3QhMhqCNiGQAzgxBchAQA0glBmhDQBTg1A8gaQBHgeBGgHQBKgHBFASQBLATArAsQBXBRiTCdQhpBujMCGQhcA5gyAWQhFAfhCAFIgdACQg5AAg3gTg");
	this.shape_1.setTransform(48.5009,33.8507);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_31_1, new cjs.Rectangle(-0.8,-0.9,98.7,69.5), null);


(lib.Path_29_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_30();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_29_1, new cjs.Rectangle(0,0,19,7), null);


(lib.Path_28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("AiBjwQAigTAgAHQBAARBEBzQA3BdANBlQAKBTgSA7QgRA2gTgUQgVgXADhnQAEhZg5hBQgjgqg0gZQgtgWgVg4QgTg2AVgLg");
	this.shape.setTransform(14.0591,25.599);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABdD6QgVgXADhnQAEhZg5hBQgjgqg0gZQgtgWgVg4QgTg2AVgLQAigTAgAHQBAARBEBzQA3BdANBlQAKBTgSA7QgMAngOAAQgFAAgFgFg");
	this.shape_1.setTransform(14.0591,25.599);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_28, new cjs.Rectangle(-1,-0.9,30.2,53), null);


(lib.Path_26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_27();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_26, new cjs.Rectangle(0,0,4,27), null);


(lib.Path_23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EBEDB2").ss(0.1).p("AhBkLQAIgNALgIQALgJAIADQAIADACAdQACAdAKAEQAGADAPgHQAPgHAIAEQAHAEAEAMQAEANAFAFQANALAmgPQAlgOAGAHQAGAGgMAeQgNAfAIALQALAQAxgFQAvgGAAACQABABg6AZQg7AagCAaQgCAWAsAfQArAegDAFQgCAFgigFQgjgFgHAKQgKAOAqA6QAqA6gHAIQgDAFgYgJQgdgLgUAEQgjAIgeA9QgcA5gMgBQgOgBgTg9QgUg8gRgBQgIAAgMALQgMAKgGgDQgIgCgEgVQgEgXgJgFQgQgKgrAeQgqAcgEgDQgCgDAIgQQALgWADgUQACgSgGgZQgGgUAGgNQAGgQAUgMQARgLgBgFQgBgLgtgHQgrgHAAgBQAAgCA4gFQA5gGADgOQADgNgsgbQgsgbACgFQACgEAzAKQA0AJAHgMQAFgJgQgZQgQgZACgCQADgCAXAQQAZAQAIgFQAGgEgIgnQgJgsAPgZg");
	this.shape.setTransform(24.9752,29.6117);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EAECB1").s().p("AAVEnQgOgBgTg9QgUg8gRgBQgIAAgMALQgMAKgGgDQgIgCgEgVQgEgXgJgFQgQgKgrAeQgqAcgEgDQgCgDAIgQQALgWADgUQACgSgGgZQgGgUAGgNQAGgQAUgMQARgLgBgFQgBgLgtgHQgrgHAAgBQAAgCA4gFQA5gGADgOQADgNgsgbQgsgbACgFQACgEAzAKQA0AJAHgMQAFgJgQgZQgQgZACgCQADgCAXAQQAZAQAIgFQAGgEgIgnQgJgsAPgZQAIgNALgIQALgJAIADQAIADACAdQACAdAKAEQAGADAPgHQAPgHAIAEQAHAEAEAMQAEANAFAFQANALAmgPQAlgOAGAHQAGAGgMAeQgNAfAIALQALAQAxgFQAvgGAAACQABABg6AZQg7AagCAaQgCAWAsAfQArAegDAFQgCAFgigFQgjgFgHAKQgKAOAqA6QAqA6gHAIQgDAFgYgJQgdgLgUAEQgjAIgeA9QgcA4gLAAIgBAAg");
	this.shape_1.setTransform(24.9752,29.6117);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_23, new cjs.Rectangle(-0.9,-0.9,51.8,61.1), null);


(lib.Path_22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaCKQgOgbAQhOQARhNgTgmQgRgiAKgUQAGgMAKgCQAkgIAKANQAQATgOBKQgNBEgBA/QgBAgACASIgPAUQgFAFgGAAQgJAAgJgQg");
	this.shape.setTransform(3.7619,15.4754);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_22, new cjs.Rectangle(0,0.1,7.5,30.799999999999997), null);


(lib.Path_17_0_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_17_1_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17_0_1, new cjs.Rectangle(0,0,6,28), null);


(lib.Path_16_0_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_16_1_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16_0_1, new cjs.Rectangle(0,0,13,19), null);


(lib.Path_15_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_15_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15_1_1, new cjs.Rectangle(0,0,22,18), null);


(lib.Path_14_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_14_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14_1_1, new cjs.Rectangle(0,0,26,9), null);


(lib.Path_13_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_13_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13_1_1, new cjs.Rectangle(0,0,29,1), null);


(lib.Path_12_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_12_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12_1_1, new cjs.Rectangle(0,0,28,5), null);


(lib.Path_11_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_11_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11_1_1, new cjs.Rectangle(0,0,14,15), null);


(lib.Path_10_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_10_3();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_2_1, new cjs.Rectangle(0,0,14,25), null);


(lib.Path_10_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7AC943").s().p("Ehj/A4QMAAAhwfMDH/AAAMAAABwfg");
	this.shape.setTransform(640,360);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_4, new cjs.Rectangle(0,0,1280,720), null);


(lib.Path_9_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0774E").s().p("AlrDmQhfAAhEhEQhDhDAAhfQAAheBDhDQBEhEBfAAILXAAQBfAABEBEQBDBDAABeQAABfhDBDQhEBEhfAAg");
	this.shape.setTransform(59.375,22.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_3_1, new cjs.Rectangle(0,0,118.8,46), null);


(lib.Path_9_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_9_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_1_1, new cjs.Rectangle(0,0,6,26), null);


(lib.Path_8_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_8_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_1_1, new cjs.Rectangle(0,0,6,28), null);


(lib.Path_7_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0774E").s().p("ArTDlQheABhEhDQhDhEAAhfQAAheBDhDQBEhEBeAAIWmAAQBfAABEBEQBDBDAABeQAABfhDBEQhEBDhfgBg");
	this.shape.setTransform(95.3,22.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_6, new cjs.Rectangle(0,0,190.6,45.9), null);


(lib.Path_7_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_7_5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_4, new cjs.Rectangle(0,0,16,13), null);


(lib.Path_7_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_7_3();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_2_1, new cjs.Rectangle(0,0,13,19), null);


(lib.Path_6_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(0.2).p("AAInmQhSAAhIChQgzBzg7DrQgqDBBLCGQBLCHCaAAQB6AAA5iHQAhhOArj5QAli4hZimQgnhKg1grQg2gsg3AAg");
	this.shape.setTransform(27.2143,48.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D1D1B").s().p("AjfFfQhLiFAqjBQA7jrAzhzQBIigBSgBQA3ABA2ArQA1ArAnBKQBZCnglC3QgrD5ghBNQg5CHh6AAQiaAAhLiHg");
	this.shape_1.setTransform(27.2143,48.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_7, new cjs.Rectangle(-1,-0.9,56.4,99.30000000000001), null);


(lib.Path_6_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_6_6();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_5, new cjs.Rectangle(0,0,18,9), null);


(lib.Path_6_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_6_4();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_3_1, new cjs.Rectangle(0,0,22,18), null);


(lib.Path_6_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_6_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_1_2, new cjs.Rectangle(0,0,25,23), null);


(lib.Path_5_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0774E").s().p("ArSDlQhgABhDhDQhDhEAAhfQAAheBDhDQBEhEBfAAIWmAAQBfAABDBEQBDBDAABeQAABfhDBEQhDBDhfgBg");
	this.shape.setTransform(95.3,22.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_8, new cjs.Rectangle(0,0,190.6,45.9), null);


(lib.Path_5_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_5_7();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_6, new cjs.Rectangle(0,0,15,13), null);


(lib.Path_5_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_5_5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_4, new cjs.Rectangle(0,0,25,9), null);


(lib.Path_5_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_5_3_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_2_1, new cjs.Rectangle(0,0,20,19), null);


(lib.Path_4_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F8D27F").ss(0.1).p("AAAlyQgVAAgRB6QgRB3AACUQAACfAMBZQAPBoAcAAQAcAAAOhoQAOhdAAibQAAiVgQh2QgRh6gXAAg");
	this.shape.setTransform(5.625,37.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7D27F").s().p("AgrEMQgMhaAAifQAAiUARh2QARh6AVgBQAXABARB6QAQB1AACVQAACbgOBeQgOBngcgBQgcABgPhng");
	this.shape_1.setTransform(5.625,37.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_8, new cjs.Rectangle(-0.9,-0.9,13.1,76.10000000000001), null);


(lib.Path_4_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_4_7();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_6, new cjs.Rectangle(0,0,21,9), null);


(lib.Path_4_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_4_5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_4, new cjs.Rectangle(0,0,29,2), null);


(lib.Path_4_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_4_3_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_2_1, new cjs.Rectangle(0,0,25,23), null);


(lib.Path_3_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0774E").s().p("ArSDlQhfABhEhDQhDhDAAhgQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABghDBDQhDBDhggBg");
	this.shape.setTransform(95.275,22.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_9, new cjs.Rectangle(0,0,190.6,45.9), null);


(lib.Path_3_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#7C4938").ss(0.1).p("AAAlyQgOAAgLB6QgMB3AACUQAACeAJBaQAJBoATAAQATAAAKhoQAIhcAAicQAAiVgKh2QgMh6gPAAg");
	this.shape.setTransform(3.8,37.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7C4938").s().p("AgcEMQgJhbABieQgBiUAMh2QAMh6AOgBQAPABALB6QAKB1ABCVQAACcgJBdQgKBngTgBQgSABgKhng");
	this.shape_1.setTransform(3.8,37.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_8, new cjs.Rectangle(-0.9,-0.9,9.5,76.10000000000001), null);


(lib.Path_3_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_3_7();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_6, new cjs.Rectangle(0,0,16,11), null);


(lib.Path_3_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_3_5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_4_1, new cjs.Rectangle(0,0,20,9), null);


(lib.Path_3_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_3_3_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_2_2, new cjs.Rectangle(0,0,20,19), null);


(lib.Path_2_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_11();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_10, new cjs.Rectangle(0,0,5,71), null);


(lib.Path_2_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_9();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_8, new cjs.Rectangle(0,0,10,31), null);


(lib.Path_2_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_7();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_6, new cjs.Rectangle(0,0,13,10), null);


(lib.Path_2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_4, new cjs.Rectangle(0,0,17,16), null);


(lib.Path_2_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_3_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_2_2, new cjs.Rectangle(0,0,25,23), null);


(lib.Path_2_0_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAWCcQgNgQAUg8QARgzgigsQgUgdglgVQgggRgHgkQgHghATgFQAfgHAWAIQAwARAjBLQAcA9gHA8QgFAygYAgQgPAUgKAAQgFAAgEgEg");
	this.shape.setTransform(8.6017,16.0844);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_0_2, new cjs.Rectangle(0,0.1,17.3,32), null);


(lib.Path_1_20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0774E").s().p("ArSDlQhfABhEhDQhDhDAAhgQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABghDBDQhDBDhggBg");
	this.shape.setTransform(95.275,22.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_20, new cjs.Rectangle(0,0,190.6,45.9), null);


(lib.Path_1_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_19();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_18, new cjs.Rectangle(0,0,14,28), null);


(lib.Path_1_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_17();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_16, new cjs.Rectangle(0,0,10,31), null);


(lib.Path_1_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_15();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_14, new cjs.Rectangle(0,0,17,9), null);


(lib.Path_1_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_13();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_12, new cjs.Rectangle(0,0,10,20), null);


(lib.Path_1_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_11();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_10, new cjs.Rectangle(0,0,25,23), null);


(lib.Path_1_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_9();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_8, new cjs.Rectangle(0,0,24,38), null);


(lib.Path_1_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAtE0QgJgNgGgPQgGgPgBgQQgCgRAEgPQgiAXghgFQgTgDgSgPQgCAMgEAJQgHAPgKANQgJALgOAKQgPALgRAEQAAgPAHgUQAHgPAKgMQALgNAMgJQAKgGAKgEQgYgagRgtIgLAMQgOAOgRALQgRALgSAGQgVAIgVAAQAHgPASgUQAPgOAQgKQAPgKAUgHQALgEAKgCQgQg0gGg4IgCACQgOANgSAKQgRAKgTAGQgYAGgSgBQAKgSARgPQAMgLATgLQATgKASgGIAOgDQgGg/ACg/QgMAIgSAGQgSAHgUADQgYADgSgFQAMgQATgMQAQgKAUgHQAQgGAWgEIAHAAQAEhNANhMIGGBCQgLBEgQA9QANAJAJAKQAOANALASQAMAUAEATQgSgEgVgNQgRgMgNgNIgGgGQgVBHgWAwIACABQATANALAMQANANALASQALAUAEATQgUgFgSgMQgQgKgOgPQgLgMgGgKQgVArgWAiIAQALQAPANAMAPQAMAPAJASQAKAVACATQgUgHgRgOQgPgMgMgPQgNgQgIgRIgFgMQgeApgfAWQAOAJAKAOQAKANAFAPQAGAOACARQACAUgFAPQgNgHgOgRg");
	this.shape.setTransform(27.825,33.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_6, new cjs.Rectangle(0,0,55.7,66.4), null);


(lib.Path_1_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMAtQgWgoAAgvIgCgLQgFgMgJgBQAHgBAGABQANADAAALQAEAuADAOQAHApANASQgHgJgIgNg");
	this.shape.setTransform(2.6875,6.7542);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_5, new cjs.Rectangle(0,0.1,5.4,13.4), null);


(lib.Path_1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_4();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_3, new cjs.Rectangle(0,0,3,16), null);


(lib.Path_1_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("AkYArQAJApAdAUQA7AoCMgcQBwgWBag/QBJgxAig4QAfg0gegBQghgBhPBMQhEBBhcACQg8ABg4gXQgygUg7AYQg4AWAGAYg");
	this.shape.setTransform(28.2337,12.8595);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjyBoQgdgUgJgpQgGgYA4gWQA7gYAyAUQA4AXA8gBQBcgCBEhBQBPhMAhABQAeABgfA0QgiA4hJAxQhaA/hwAWQg5AMgsAAQg/AAgjgYg");
	this.shape_1.setTransform(28.2337,12.8595);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_1_1, new cjs.Rectangle(-0.9,-0.9,58.3,27.5), null);


(lib.Path_1_0_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F8D27F").ss(0.1).p("ACkgwQAriCgohdQgohdhiAHQhiAHg/BtQg+BuAKCTQAKCVBNBkQBNBkBigHQAtgDAPgnQAMgegChEQgEhUAAguQABhRATg3g");
	this.shape.setTransform(18.7199,35.9266);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7D27F").s().p("AhhEJQhNhkgKiVQgKiTA+huQA/htBigHQBigHAoBdQAoBdgrCCQgTA3gBBRQAAAuAEBUQACBEgMAeQgPAngtADIgNABQhaAAhIheg");
	this.shape_1.setTransform(18.7199,35.9266);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_0_3, new cjs.Rectangle(-0.9,-0.9,39.3,73.7), null);


(lib.Path_1_21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("AhJkaQAigKAZAPQAzAiAiCHQAcBtgLBsQgJBYgcA3QgaA0gMgaQgNgcAYhpQAWhbgjhRQgVg0gngnQgigigFg/QgGg8AVgHg");
	this.shape.setTransform(9.099,28.8213);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANEWQgNgcAYhpQAWhbgjhRQgVg0gngnQgigigFg/QgGg8AVgHQAigKAZAPQAzAiAiCHQAcBtgLBsQgJBYgcA3QgRAjgMAAQgFAAgEgJg");
	this.shape_1.setTransform(9.099,28.8213);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_21, new cjs.Rectangle(-0.9,-0.8,20.099999999999998,59.3), null);


(lib.Path_0_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("Ag9kUQAogFAZATQA3AoAWCGQARBrgaBlQgVBSgnAwQgjAtgKgaQgMgdAqhgQAjhTgdhSQgRg1gogrQgjgmACg9QACg5AYgDg");
	this.shape.setTransform(8.8715,27.939);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AghENQgMgdAqhgQAjhTgdhSQgRg1gogrQgjgmACg9QACg5AYgDQAogFAZATQA3AoAWCGQARBrgaBlQgVBSgnAwQgVAcgNAAQgHAAgEgJg");
	this.shape_1.setTransform(8.8715,27.939);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0_2, new cjs.Rectangle(-0.9,-0.9,19.599999999999998,57.699999999999996), null);


(lib.Path_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F8D27F").ss(0.1).p("AikgwQgriDAohcQAohdBjAHQBiAHA/BtQA/BugKCTQgKCUhNBkQhNBlhjgHQgtgDgQgoQgMgdAChFQAFhTgBguQgBhRgTg3g");
	this.shape.setTransform(18.7354,35.9016);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7D27F").s().p("AhNFmQgtgDgQgoQgMgdAChFQAFhTgBguQgBhRgTg3QgriDAohcQAohdBjAHQBiAHA/BtQA/BugKCTQgKCUhNBkQhIBehbAAIgNAAg");
	this.shape_1.setTransform(18.7354,35.9016);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_34, new cjs.Rectangle(-1,-0.9,39.5,73.7), null);


(lib.Group_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_146();
	this.instance.setTransform(-0.4,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(-0.4,0,31.5,46), null);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_145();
	this.instance.setTransform(-0.45,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-0.4,0,31.5,46), null);


(lib.Path_1_22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A0774E").s().p("ArSDlQhfABhEhDQhDhDAAhgQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABghDBDQhDBDhggBg");
	this.shape_2.setTransform(95.275,22.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_22, new cjs.Rectangle(0,0,190.6,45.9), null);


(lib.Group_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_35 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7AC943").s().p("Ehj/A4QMAAAhwfMDH/AAAMAAABwfg");
	this.shape_2.setTransform(640,360);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_35, new cjs.Rectangle(0,0,1280,720), null);


(lib.Image_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_3, new cjs.Rectangle(0,0,1040,32), null);


(lib.Group_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgBgGIgEgQIgBgBQgxAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgJAAgDgJIgLgrQgDgMgKgHQgegXgTgdQgHgMgPgBIgOgBQgOgCgDgOIgMhEQgBgIAEgGQAEgGAIgCIAUgGQAOgDAGgNQAOgeAcgaQADgDAAgGQABgfgUgaIgFgGIASgFQAqgGAoAVQAGADACADQAEAFAIgCQBvgcBfA0QA/AiAWA8IAKAkQABAHAEAAIAOACQAMABAJgIQAJgIACgMQACgIgHgEQgJgFgHAFQgGAFADAIQAKgBAAAIQAAAEgFAEQgGAFgIgFQgIgHABgPQACgOALgGQAQgIAQALQAOAKgFASQgEAUgQAKQgQAJgVgEIgGgBIgJAqQgOArgnAhQgNALgDAPIgMAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAFgEQAEgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgQADgPAGIgMAFQgEACACAEQACADAEgCIALgFQAPgFAPgDQAxgJAuAWIACABQAAAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgDgEgCQgigRglAAQgOAAgPADg");
	this.shape.setTransform(28.1963,20.0595);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_1, new cjs.Rectangle(0,0,56.4,40.1), null);


(lib.Image_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_16();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_15, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_14();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_13, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_12();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_11, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_10();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_9, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_8();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_7, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_6();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_5, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_4();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_3_1, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_1_1, new cjs.Rectangle(0,0,1040,32), null);


(lib.Image_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Image_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_17, new cjs.Rectangle(0,0,1040,32), null);


(lib.Group_2_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA6DIQgGAAgDgCQgCgCgCgGIgEgQIgBgBQgwAIgxgHIgFARQgCAJgKAAIg5AAQgGAAgCgCQgDgBgBgGIgMgrQgCgMgKgHQgfgXgSgdQgHgMgPgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAPgfAagZQADgDAAgGQABgfgUgaIgEgGIARgFQAqgGAoAVQAGADADADQADAFAJgCQBugcBfA0QA/AiAXA8QADAIAGAcQACAHAEAAIANACQAMABAKgIQAJgIACgMQABgIgGgEQgJgGgIAGQgFAFADAIQAJgBAAAIQABAEgFAEQgHAGgHgGQgJgHACgPQACgOAKgGQAQgIARALQANAJgEATQgFAUgQAKQgQAJgVgEIgFgBIgJAqQgPAsgnAgQgNALgDAPIgLAtQgCAGgDACQgCACgHAAgAixhKQgFAFAAAGQABAGAEAEQAEAEAGAAQAGAAAEgEQAFgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgRADgOAGIgMAFQgEACACAEQACADAEgCIALgFQAOgFAQgDQAwgJAuAWIACABQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgEgEgBQgjgRgkAAQgOAAgPADg");
	this.shape.setTransform(28.2108,20.0595);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_7, new cjs.Rectangle(0,0,56.4,40.1), null);


(lib.Group_2_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgBgGIgFgQIAAgBQgxAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgJAAgDgJIgLgrQgDgMgKgHQgegXgTgdQgHgMgPgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAOgeAcgaQADgDAAgGQABgfgUgaIgFgGIASgFQAqgGAoAVQAGADACADQAEAFAIgCQBvgcBfA0QA/AiAWA8IAKAkQABAHAEAAIAOACQAMABAJgIQAJgIACgMQACgIgHgEQgJgGgHAGQgGAEADAJQAKgBAAAIQAAAEgFAEQgGAFgIgFQgIgHABgPQACgOALgGQAQgIAQALQAOAJgFATQgEAUgQAKQgQAJgVgEIgGgBIgJAqQgOArgnAhQgNALgEAPIgLAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAFgEQAEgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgQADgPAGIgMAFQgEACACAEQACADAEgCIALgFQAPgFAPgDQAxgJAuAWIACABQAAAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgDgEgCQgigRglAAQgOAAgPADg");
	this.shape.setTransform(28.1947,20.0595);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_6, new cjs.Rectangle(0,0,56.4,40.1), null);


(lib.Group_2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgBgGIgFgQIAAgBQgxAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgJAAgDgJIgLgrQgDgMgKgHQgegXgTgdQgHgMgPgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAOgeAcgaQADgDAAgGQABgfgUgaIgFgGIASgFQAqgGAoAVQAGADACADQAEAFAIgCQBvgcBfA0QA/AiAWA8IAKAkQABAHAEAAIAOACQAMABAJgIQAJgIACgMQACgIgHgEQgJgGgHAGQgGAEADAJQAKgBAAAIQAAAEgFAEQgGAFgIgFQgIgHABgPQACgOALgGQAQgIAQALQAOAJgFATQgEAUgQAKQgQAJgVgEIgGgBIgJAqQgOArgnAhQgNALgEAPIgLAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAFgEQAEgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgQADgPAGIgMAFQgEACACAEQACADAEgCIALgFQAPgFAPgDQAxgJAuAWIACABQAAAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgDgEgCQgigRglAAQgOAAgPADg");
	this.shape.setTransform(28.1947,20.0595);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_5, new cjs.Rectangle(0,0,56.4,40.1), null);


(lib.Group_2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgDgCQgCgCgCgGIgEgQIgBgBQgwAIgxgHIgEARQgDAJgJAAIg6AAQgGAAgCgCQgDgBgBgGIgMgrQgCgMgKgHQgfgXgSgdQgHgMgPgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQANgDAHgNQAPgfAagZQADgDAAgGQABgfgUgaIgEgGIARgFQAqgGApAVQAFADADADQADAFAJgCQBugcBfA0QA/AiAXA8QADAIAGAcQACAHAEAAIANACQAMABAKgIQAJgIACgMQABgIgGgEQgJgGgIAGQgFAEADAJQAJgBAAAIQABAEgFAEQgHAGgHgGQgJgHACgPQACgOAKgGQARgJAQAMQANAJgEATQgFAUgQAKQgQAJgVgEIgFgBIgJAqQgPAsgnAgQgMAKgEAQIgLAtQgCAGgDACQgCACgHAAgAixhKQgFAFABAGQAAAGAEAEQAEAEAGAAQAGAAAEgEQAFgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgRADgOAGIgMAFQgEACACAEQACADAEgCIALgFQAOgFAQgDQAwgJAuAWIACABQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgEgEgBQgigRglAAQgOAAgPADg");
	this.shape.setTransform(28.2108,20.0679);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_4, new cjs.Rectangle(0,0.1,56.4,40), null);


(lib.Group_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgBgGIgEgQIgBgBQgxAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgFAAgDgCQgCgBgCgGIgLgrQgDgMgJgHQgggXgSgdQgHgMgPgBIgNgBQgPgCgDgOIgMhEQgBgIAEgGQAEgGAIgCIAUgGQAOgDAGgNQAOgeAcgaQADgDAAgGQABgfgUgaIgFgGIASgFQAqgGAoAVQAFADADADQAEAFAIgCQBvgcBfA0QA/AiAWA8QAFALAFAZQABAHAEAAIAOACQAMABAJgIQAJgIACgMQACgIgHgEQgJgGgHAGQgGAFADAIQAKgBAAAIQAAAEgFAEQgGAFgIgFQgIgHABgPQACgOALgGQAQgIAQALQAOAKgFASQgEAUgQAKQgQAJgVgEIgGgBIgJAqQgOArgnAhQgNALgDAPIgMAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAFgEQAEgEAAgGQAAgGgEgFQgFgEgGAAQgFAAgFAEgAgoiiQgQADgPAGIgMAFQgEACACAEQACADAEgCIALgFQAPgFAPgDQAxgJAuAWIACABQAAAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgDgEgCQgigRglAAQgOAAgPADg");
	this.shape.setTransform(28.1963,20.0595);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_3, new cjs.Rectangle(0,0,56.4,40.1), null);


(lib.Group_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgCgGIgEgQIgBgBQgwAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgKAAgCgJIgLgrQgDgMgKgHQgegXgTgdQgIgMgOgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAPgfAagZQAEgDAAgGQAAgggUgZIgEgGIASgFQApgGApAVQAGADACADQAEAFAIgCQBvgcBeA0QA/AiAXA8QADAIAGAcQACAHAEAAIAOACQAMABAJgIQAJgIACgMQABgIgGgEQgKgGgGAGQgGAEADAJQAJgBABAIQAAAEgFAEQgGAGgIgGQgJgHACgPQACgOALgGQAQgIAQALQAOAJgFATQgEAUgQAKQgQAJgWgEIgFgBIgJAqQgNArgoAhQgNALgEAPIgLAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAEgEQAFgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgRADgOAGIgMAFQgEACACAEQACADAEgCIALgFQAOgFAQgDQAxgJAuAWIABABQABAAAAAAQABAAAAgBQABAAAAgBQABAAAAgBQACgDgEgCQgjgRglAAQgOAAgOADg");
	this.shape.setTransform(28.2436,20.0679);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_2, new cjs.Rectangle(0.1,0.1,56.4,40), null);


(lib.Group_2_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgCgGIgEgQIgBgBQgwAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgGAAgCgCQgDgBgBgGIgLgrQgDgMgKgHQgegWgTgeQgHgMgPgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAPgfAagZQAEgDAAgGQAAgggUgZIgEgGIASgFQApgGApAVQAGADACADQAEAFAIgCQBvgcBeA0QA/AiAXA8QADAIAGAcQACAHAEAAIAOACQALABAKgIQAJgIACgMQABgIgGgEQgKgGgGAGQgGAEADAJQAJgBABAIQAAAEgFAEQgGAGgIgGQgJgHACgPQACgOAKgGQARgIAQALQAOAJgFATQgEAUgQAKQgQAJgWgEIgFgBIgJAqQgNArgoAhQgNALgEAPIgLAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAEgEQAFgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgRADgOAGIgMAFQgEACACAEQACADAEgCIALgFQAOgFAQgDQAxgJAuAWIABABQABAAAAAAQABAAAAgBQABAAAAgBQABAAAAgBQACgDgEgCQgjgRglAAQgOAAgOADg");
	this.shape.setTransform(28.2436,20.0679);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_1_1, new cjs.Rectangle(0.1,0.1,56.4,40), null);


(lib.Group_2_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgBgGIgFgQIgBgBQgwAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgKAAgCgJIgLgrQgDgMgKgHQgegXgTgdQgIgMgOgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAPgfAagZQAEgDAAgGQABgfgUgaIgFgGIASgFQApgGApAVQAGADACADQAEAFAIgCQBvgcBeA0QA/AhAXA9IAKAkQABAHAEAAIAOACQAMABAJgIQAJgIACgMQABgIgGgEQgJgGgHAGQgGAEADAJQAJgBABAIQAAAEgFAEQgGAGgIgGQgIgHABgPQACgOALgGQAQgIAQALQAOAJgFATQgEAUgQAKQgQAJgVgEIgGgBIgJAqQgNArgoAhQgNALgEAPIgLAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAFgEQAEgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgQADgPAGIgMAFQgEACACAEQACADAEgCIALgFQAPgFAPgDQAxgJAuAWIABABQABAAAAAAQABAAAAgBQABAAAAgBQABAAAAgBQACgDgEgCQgigRglAAQgOAAgPADg");
	this.shape.setTransform(28.1947,20.0679);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_0, new cjs.Rectangle(0,0.1,56.4,40), null);


(lib.Group_2_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E05A69").s().p("AA7DIQgHAAgCgCQgDgCgBgGIgFgQIgBgBQgwAIgxgHIgEARQgCAFgCACQgDACgFAAIg6AAQgKAAgCgJIgLgrQgDgMgKgHQgegXgTgdQgIgMgOgBIgOgBQgPgCgCgOIgMhEQgBgIAEgGQAEgGAHgCIAVgGQAOgDAGgNQAPgfAbgZQADgDAAgGQABgfgUgaIgFgGIASgFQAqgGAoAVQAGADACADQAEAFAIgCQBvgcBeA0QA/AhAXA9IAKAkQABAHAEAAIAOACQAMABAJgIQAJgIACgMQABgIgGgEQgJgGgHAGQgGAEADAJQAJgBABAIQAAAEgFAEQgGAGgIgGQgIgHABgPQACgOALgGQAQgIAQALQAOAJgFATQgEAUgQAKQgQAJgVgEIgGgBIgJAqQgNArgoAhQgNALgEAPIgLAtQgCAGgCACQgDACgHAAgAixhKQgEAFAAAGQAAAGAEAEQAEAEAGAAQAGAAAFgEQAEgEAAgGQAAgGgEgFQgFgEgGAAQgGAAgEAEgAgoiiQgQADgPAGIgMAFQgEACACAEQACADAEgCIALgFQAPgFAPgDQAxgJAuAWIABABQABAAAAAAQABAAAAgBQABAAAAgBQABAAAAgBQACgDgEgCQgigRglAAQgOAAgPADg");
	this.shape_1.setTransform(28.1947,20.0595);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_8, new cjs.Rectangle(0,0,56.4,40.1), null);


(lib.Path_12_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_12_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12_3, new cjs.Rectangle(0,0,4,18), null);


(lib.Path_10_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPA0QgaguAAg2QgBgGgCgHQgGgNgKgCQAIgBAGACQAPADABAMIAIBGQAIAuAPAVQgIgKgIgPg");
	this.shape_1.setTransform(3.1,7.7175);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_5, new cjs.Rectangle(0,0,6.2,15.5), null);


(lib.Path_8_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("AhGk+QAtgGAeAWQA/AuAZCaQAUB8geB0QgYBegsA3QgpA0gMgeQgNgiAwhuQAohfghhfQgUg9gugxQgogrAChGQAChCAcgEg");
	this.shape.setTransform(10.1952,32.1245);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmE1QgNgiAwhuQAohfghhfQgUg9gugxQgogrAChGQAChCAcgEQAtgGAeAWQA/AuAZCaQAUB8geB0QgYBegsA3QgaAhgOAAQgJAAgEgLg");
	this.shape_1.setTransform(10.1952,32.1245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_5, new cjs.Rectangle(-0.9,-0.9,22.2,66.10000000000001), null);


(lib.Path_1_23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZCzQgOgSAWhFQAUg7gngzQgYghgqgYQglgUgIgpQgHgmAVgFQAjgIAbAJQA3ATAoBXQAgBFgIBGQgGA5gbAlQgSAXgMAAQgFAAgFgFg");
	this.shape_3.setTransform(9.9337,18.4902);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_23, new cjs.Rectangle(0,0.1,19.9,36.8), null);


(lib.Path_36 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeCfQgQgfAThaQAThZgWgrQgTgoALgWQAHgOAMgDQApgJAMAPQASAWgQBVQgPBOgBBJQgBAkACAVIgRAXQgGAGgHAAQgLAAgKgSg");
	this.shape_3.setTransform(4.2882,17.832);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_36, new cjs.Rectangle(0,0.1,8.6,35.5), null);


(lib.Group_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_1.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_1, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_9_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_9_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_5, new cjs.Rectangle(0,0,29,28), null);


(lib.Path_8_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_8_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_6, new cjs.Rectangle(0,0,24,23), null);


(lib.Path_7_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_7_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_7, new cjs.Rectangle(0,0,29,28), null);


(lib.Path_6_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_6_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_8, new cjs.Rectangle(0,0,24,23), null);


(lib.Path_5_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_5_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_9, new cjs.Rectangle(0,0,29,28), null);


(lib.Path_4_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_4_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_9, new cjs.Rectangle(0,0,29,28), null);


(lib.Path_1_24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_24, new cjs.Rectangle(0,0,29,45), null);


(lib.Group_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_2.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_2, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_17_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_17_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17_4, new cjs.Rectangle(0,0,7,32), null);


(lib.Path_16_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_16_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16_3, new cjs.Rectangle(0,0,14,21), null);


(lib.Path_15_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_15_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15_4, new cjs.Rectangle(0,0,25,21), null);


(lib.Path_14_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_14_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14_4, new cjs.Rectangle(0,0,29,10), null);


(lib.Path_13_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_13_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13_3, new cjs.Rectangle(0,0,33,1), null);


(lib.Path_12_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_12_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12_4, new cjs.Rectangle(0,0,32,6), null);


(lib.Path_11_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_11_0();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11_3, new cjs.Rectangle(0,0,16,17), null);


(lib.Path_10_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_10_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_6, new cjs.Rectangle(0,0,16,29), null);


(lib.Path_9_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_9_0_2();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_6, new cjs.Rectangle(0,0,7,30), null);


(lib.Path_8_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_8_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_7, new cjs.Rectangle(0,0,7,32), null);


(lib.Path_7_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_7_0_2();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_8, new cjs.Rectangle(0,0,15,22), null);


(lib.Path_6_0_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_6_1_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_0_3, new cjs.Rectangle(0,0,25,21), null);


(lib.Path_5_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_5_0_2();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_10, new cjs.Rectangle(0,0,28,10), null);


(lib.Path_4_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_4_0_2();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_10, new cjs.Rectangle(0,0,33,2), null);


(lib.Path_3_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_3_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_10, new cjs.Rectangle(0,0,23,11), null);


(lib.Path_2_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_12, new cjs.Rectangle(0,0,19,18), null);


(lib.Path_1_25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_1_0_2();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_25, new cjs.Rectangle(0,0,11,23), null);


(lib.Path_37 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_37, new cjs.Rectangle(0,0,5,30), null);


(lib.Group_3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_144();
	this.instance.setTransform(-0.45,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3_2, new cjs.Rectangle(-0.4,0,36,52.5), null);


(lib.Group_1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A0774E").s().p("Ah3CCQgHgDgCgHQgCgHAFgGIBOhPIAEgDIgfgeQgKgJgGgHQgFgGACgHQABgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhMBOQgHAGgFAAIgEgBg");
	this.shape_3.setTransform(12.9893,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_3, new cjs.Rectangle(0,0,26,26.1), null);


(lib.Path_38 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.1).p("AiTkSQAogWAjAJQBJATBOCDQA/BqAOB0QAMBdgVBDQgTA+gWgXQgYgaAEh1QAEhmhBhKQgogvg7gdQg0gZgXhAQgWg9AYgNg");
	this.shape_4.setTransform(15.9921,29.1534);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABqEcQgYgaAEh1QAEhmhBhKQgogvg7gdQg0gZgXhAQgWg9AYgNQAogWAjAJQBJATBOCDQA/BqAOB0QAMBdgVBDQgOAtgPAAQgGAAgGgGg");
	this.shape_5.setTransform(15.9921,29.1534);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_38, new cjs.Rectangle(-1,-0.8,34.1,60), null);


(lib.Group_1_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_4.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_4, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_6_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("AhVlGQAngMAdASQA8AnAnCcQAgB+gNB9QgKBlggBBQgeA8gOgeQgPghAch5QAZhpgoheQgYg8guguQgngngGhJQgGhFAXgIg");
	this.shape.setTransform(10.4915,33.323);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPFCQgPghAch5QAZhpgoheQgYg8guguQgngngGhJQgGhFAXgIQAngMAdASQA8AnAnCcQAgB+gNB9QgKBlggBBQgUAogNAAQgHAAgEgKg");
	this.shape_1.setTransform(10.4915,33.323);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_9, new cjs.Rectangle(-0.9,-0.8,22.9,68.3), null);


(lib.Path_1_26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#F8D27F").ss(0.1).p("AC+g4QAyiXguhqQguhshyAIQhyAHhIB/QhJB/AMCrQAMCrBZB0QBZB0BxgIQA1gDASguQANgigChPQgFhhABg1QABhdAVhBg");
	this.shape_4.setTransform(21.6484,41.5732);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F7D27F").s().p("AhwEyQhZh0gMirQgMirBJh/QBIh/BygHQBygIAuBsQAuBqgyCXQgVBBgBBdQgBA1AFBhQACBPgNAiQgSAug1ADIgPABQhoAAhThtg");
	this.shape_5.setTransform(21.6484,41.5732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_26, new cjs.Rectangle(-0.9,-0.9,45.199999999999996,85), null);


(lib.Path_39 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#F8D27F").ss(0.1).p("Ai+g4QgyiXAuhqQAvhsByAIQByAIBJB+QBJB/gMCrQgLCrhaB0QhZB0hygIQg1gDgSguQgOgiADhPQAFhhgBg1QgBhdgWhBg");
	this.shape_6.setTransform(21.6762,41.5732);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F7D27F").s().p("AhZGeQg1gDgSguQgOgiADhPQAFhhgBg1QgBhdgWhBQgyiXAuhqQAvhsByAIQByAIBJB+QBJB/gMCrQgLCrhaB0QhTBthqAAIgOgBg");
	this.shape_7.setTransform(21.6762,41.5732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_39, new cjs.Rectangle(-1,-0.9,45.4,85), null);


(lib.Group_1_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_5.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_5, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Group_2_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_143();
	this.instance.setTransform(-0.45,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_9, new cjs.Rectangle(-0.4,0,35.5,52), null);


(lib.Group_1_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_6.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_6, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_3_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA0FgQgLgOgHgSQgGgTgCgQQgCgVAFgRQgnAbgmgGQgWgDgUgQQgCALgFAMQgIASgMANQgMAQgOAJQgUANgRAEQAAgSAJgVQAHgRAMgPQAOgQANgIQAJgHAOgGQgbgcgVg1IgNAPQgPAPgUANQgSAMgWAHQgaAJgWAAQAJgUAUgTQAPgQAUgMQATgMAVgIQAPgFAJgBQgQg0gKhHIgBABQgRAPgUAMQgSALgXAHQgcAHgUgBQAKgTAUgTQAQgPAVgKQAUgMAVgGIAQgEQgGhIAChIQgQAKgSAGQgVAIgXADQgbADgVgFQANgRAXgPQATgMAVgIQAUgIAYgDIAIAAQAFhSAOhcIG/BLQgNBOgSBFQAPALALALQARASALARQANAVAFAYQgVgFgXgOQgVgOgOgPIgGgHQgXBMgbA8IACACQAQAJATATQAOAPANAUQANAYAEAVQgWgFgWgPQgRgLgRgRQgLgMgIgNQgZAygZAmQALAGAIAHQASAOANARQAPASAJAUQALAXADAXQgVgHgVgRQgSgPgNgQQgOgRgKgVIgGgNQghAuglAaQAPAJANARQAKAOAHASQAGAOADAVQACAXgGARQgRgJgNgSg");
	this.shape.setTransform(31.825,37.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_11, new cjs.Rectangle(0,0,63.7,75.9), null);


(lib.Group_1_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_7.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_7, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_27_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.1).p("AlJAzQAMAxAhAWQBFAvClggQCDgaBqhKQBWg6AnhCQAlg9gjgBQgngBhdBZQhQBMhsACQhFAChDgbQg6gXhGAcQhCAZAHAdg");
	this.shape.setTransform(33.1481,15.0846);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkcB6QghgWgMgxQgHgdBCgZQBGgcA6AXQBDAbBFgCQBsgCBQhMQBdhZAnABQAjABglA9QgnBChWA6QhqBKiDAaQhDANgzAAQhLAAgpgcg");
	this.shape_1.setTransform(33.1481,15.0846);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_27_1, new cjs.Rectangle(-0.9,-0.9,68.10000000000001,32), null);


(lib.Path_23_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#EBEDB2").ss(0.1).p("AhMk6QAJgPANgJQAOgLAIAEQAJADADAiQADAiALAFQAHAEASgIQARgIAKAEQAIAEAEAPQAFAPAHAGQAPAMAsgRQArgQAIAHQAHAIgOAiQgPAlAJANQAMATA6gGQA3gGABABQAAAChDAdQhGAfgCAeQgCAaA0AlQAxAjgCAGQgDAGgogGQgpgHgIAMQgMARAyBEQAxBEgIAKQgEAFgdgLQghgMgYAFQgpAJgjBIQgVAqgDAFQgMAUgLgBQgRgCgWhHQgXhGgVgBQgJgBgOANQgOALgIgCQgJgDgFgZQgFgbgKgGQgSgLgzAjQgxAhgFgEQgDgDAKgTQANgaADgXQADgWgHgdQgHgXAGgPQAIgTAXgPQAUgNgBgGQgCgMg0gIQgzgJAAgBQAAgCBCgGQBDgHAEgRQADgPg0ggQgyggACgFQACgFA8ALQA9ALAIgOQAGgLgTgdQgSgdACgCQADgDAcATQAcATAJgGQAIgFgJguQgKgzARgeg");
	this.shape_2.setTransform(29.3252,34.7586);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EAECB1").s().p("AAZFbQgRgCgWhHQgXhGgVgBQgJgBgOANQgOALgIgCQgJgDgFgZQgFgbgKgGQgSgLgzAjQgxAhgFgEQgDgDAKgTQANgaADgXQADgWgHgdQgHgXAGgPQAIgTAXgPQAUgNgBgGQgCgMg0gIQgzgJAAgBQAAgCBCgGQBDgHAEgRQADgPg0ggQgyggACgFQACgFA8ALQA9ALAIgOQAGgLgTgdQgSgdACgCQADgDAcATQAcATAJgGQAIgFgJguQgKgzARgeQAJgPANgJQAOgLAIAEQAJADADAiQADAiALAFQAHAEASgIQARgIAKAEQAIAEAEAPQAFAPAHAGQAPAMAsgRQArgQAIAHQAHAIgOAiQgPAlAJANQAMATA6gGQA3gGABABQAAAChDAdQhGAfgCAeQgCAaA0AlQAxAjgCAGQgDAGgogGQgpgHgIAMQgMARAyBEQAxBEgIAKQgEAFgdgLQghgMgYAFQgpAJgjBIIgYAvQgLATgLAAIgBAAg");
	this.shape_3.setTransform(29.3252,34.7586);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_23_1, new cjs.Rectangle(-0.9,-0.9,60.5,71.4), null);


(lib.Group_1_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_8.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_8, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Group_1_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_9.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_9, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Path_12_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(0.2).p("AIWk0Qgzg0hZgXQhRgWhYAJQhTAIhUAjQhHAfhiA/Qh5BQg9ArQhtBMg8A6QinCeBZB+QA0BBBbAfQBRAcBWgHQBNgGBSglQA6gaBuhEQDyieB8iDQCui5hnhgg");
	this.shape.setTransform(57.3785,40.0496);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D1D1B").s().p("AmNF6Qhbgfg0hBQhZh+CnieQA8g6BthMQA9grB5hQQBig/BHgfQBUgjBTgIQBYgJBRAWQBZAXAzA0QBnBgiuC5Qh8CDjyCeQhuBEg6AaQhSAkhNAHIgiABQhEAAhBgWg");
	this.shape_1.setTransform(57.3785,40.0496);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12_5, new cjs.Rectangle(-0.8,-0.9,116.39999999999999,82), null);


(lib.Path_10_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_10_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_7, new cjs.Rectangle(0,0,12,36), null);


(lib.Path_9_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_2 = new lib.Path_9_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_7, new cjs.Rectangle(0,0,12,36), null);


(lib.Path_7_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(0.2).p("AAJo/Qg4AAgtA0QgiAogtBiQhiDhgiC9QgyDkBYCfQBaCgC2AAQCQAABEigQAnhbAzkoQArjahojEQguhXg/gzQhBg0hBAAg");
	this.shape.setTransform(32.2094,57.7248);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D1D1B").s().p("AkJGgQhYifAyjkQAii9BijhQAthiAigoQAtg0A4AAQBBAABBA0QA/AzAuBXQBoDEgrDaQgzEognBbQhECgiQAAQi2AAhaigg");
	this.shape_1.setTransform(32.2094,57.7248);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_1_2, new cjs.Rectangle(-1,-0.8,66.4,117.1), null);


(lib.Path_7_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_2 = new lib.Path_7_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_9, new cjs.Rectangle(0,0,18,15), null);


(lib.Path_6_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_6_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_10, new cjs.Rectangle(0,0,21,10), null);


(lib.Path_5_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F8D27F").ss(0.1).p("AABm2QgaAAgUCRQgUCNAACvQAAC9APBpQAQB6AiAAQAhAAARh6QAQhuAAi4QAAiwgTiMQgUiRgaAAg");
	this.shape.setTransform(6.675,43.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7D27F").s().p("AgyE9QgPhqAAi8QAAivAUiNQAUiRAaABQAagBAUCRQATCMAACwQAAC3gQBvQgRB5ghABQgigBgQh5g");
	this.shape_1.setTransform(6.675,43.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_1_2, new cjs.Rectangle(-0.9,-0.9,15.200000000000001,89.7), null);


(lib.Path_5_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_2 = new lib.Path_5_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_11, new cjs.Rectangle(0,0,18,16), null);


(lib.Path_4_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#7C4938").ss(0.1).p("AAAm2QgRAAgNCRQgNCMAACwQAAC8AKBqQALB6AWAAQAWAAAMh6QAKhvAAi3QAAixgNiLQgNiRgSAAg");
	this.shape.setTransform(4.475,43.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7C4938").s().p("AghE9QgKhqAAi8QAAiwANiMQANiRARABQASgBANCRQANCLAACxQAAC3gKBvQgMB5gWABQgWgBgLh5g");
	this.shape_1.setTransform(4.475,43.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_1_2, new cjs.Rectangle(-0.9,-0.9,10.8,89.7), null);


(lib.Path_4_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_2 = new lib.Path_4_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_11, new cjs.Rectangle(0,0,25,11), null);


(lib.Path_3_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_3_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_1_2, new cjs.Rectangle(0,0,5,84), null);


(lib.Path_3_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_3_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_12, new cjs.Rectangle(0,0,19,12), null);


(lib.Path_2_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_2_2_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_1_2, new cjs.Rectangle(0,0,16,34), null);


(lib.Path_2_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_2_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_13, new cjs.Rectangle(0,0,15,12), null);


(lib.Path_1_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_1_2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_1_2, new cjs.Rectangle(0,0,16,34), null);


(lib.Path_1_27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_2 = new lib.Path_1_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_27, new cjs.Rectangle(0,0,20,11), null);


(lib.Path_40 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance_1 = new lib.Path_0();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_40, new cjs.Rectangle(0,0,22,8), null);


(lib.Group_1_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#A0774E").s().p("Ah3CCQgIgDgCgHQgCgHAFgGIBPhPIAEgDIgvguQgGgGACgHQACgIAHgCQAIgDAGAGIAMALIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgGAIAIIBUBTQAHAIgDAIQgCAHgHACQgIACgFgFIgJgJIhDBVQgCACACADIAKAKQAEAEABAGQAAAGgEAEQgFAEgFAAQgGAAgFgEIgqgsIgCgDIgEADIhNBOQgGAGgGAAIgDgBg");
	this.shape_10.setTransform(13.0143,13.0527);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_10, new cjs.Rectangle(0,0,26.1,26.1), null);


(lib.Image_0_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Image_0_2, new cjs.Rectangle(0,0,49,49), null);


(lib.F1over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_52();
	this.instance.setTransform(-67.95,-40.55,0.5,0.5);

	this.instance_1 = new lib.Path_24();
	this.instance_1.setTransform(-19.3,16.3);

	this.instance_2 = new lib.Path_1_7();
	this.instance_2.setTransform(18.2,-30.2);

	this.instance_3 = new lib.Path_2_1_1();
	this.instance_3.setTransform(-24.55,-10.8);

	this.instance_4 = new lib.Path_3_1_1();
	this.instance_4.setTransform(0.7,-23.35);

	this.instance_5 = new lib.Path_4_1_1();
	this.instance_5.setTransform(13.25,-20.2);

	this.instance_6 = new lib.Path_5_1_1();
	this.instance_6.setTransform(24.6,-23.05);

	this.instance_7 = new lib.Path_6_0_2();
	this.instance_7.setTransform(-6.7,-11.95);

	this.instance_8 = new lib.Path_7_0_3();
	this.instance_8.setTransform(-15.6,2.65);

	this.instance_9 = new lib.Path_8_0_2();
	this.instance_9.setTransform(0.7,5.2);

	this.instance_10 = new lib.Path_9_0_3();
	this.instance_10.setTransform(-1.45,17.05);

	this.instance_11 = new lib.Path_10_1_1();
	this.instance_11.setTransform(15.3,2.6);

	this.instance_12 = new lib.Path_11_0_1();
	this.instance_12.setTransform(5.85,-8.8);

	this.instance_13 = new lib.Path_12_0_2();
	this.instance_13.setTransform(-48.25,4);

	this.instance_14 = new lib.Path_13_0_1();
	this.instance_14.setTransform(-30.2,1);

	this.instance_15 = new lib.Path_14_0_1();
	this.instance_15.setTransform(17.2,-11.65);

	this.instance_16 = new lib.Path_15_0_1();
	this.instance_16.setTransform(-34.85,11.45);

	this.instance_17 = new lib.CachedBmp_4();
	this.instance_17.setTransform(-65.3,-41.4,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_3();
	this.instance_18.setTransform(-32.5,-70,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_2();
	this.instance_19.setTransform(-25.05,49.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F1over, new cjs.Rectangle(-67.9,-70,135.9,139.9), null);


(lib.S4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,over:2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(230,245,218,0.8)").s().p("AxQGkIAAtHMAihAAAIAANHg");
	this.shape.setTransform(0.5,9);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#3C3C3B").p("ALTDlI2lAAQhfAAhEhCQhDhEAAhfQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABfhDBEQhDBChgAAg");
	this.shape_1.setTransform(-2.575,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#3C3C3B").p("AgqAaIgwguQgFgGABgIQACgHAHgCQAIgDAGAGQADACAJAJIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgHAIAIIBUBUQAHAHgDAJQgCAHgHACQgIACgFgFIgIgKIgDADIhBBSQgDADADACIAKAKQAFAFAAAGQAAAGgEAEQgEAEgGAAQgGAAgFgFIgqgrIgCgDIhRBQQgHAIgIgDQgHgCgCgHQgDgHAFgGIBQhQg");
	this.shape_2.setTransform(86.3283,-25.7518);

	this.instance = new lib.Group_1();
	this.instance.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_1},{t:this.instance},{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_227();
	this.instance_1.setTransform(-98.35,-23.45,0.5,0.5);

	this.instance_2 = new lib.Path_3_9();
	this.instance_2.setTransform(2.55,-0.05,1,1,0,0,0,95.2,22.9);
	this.instance_2.alpha = 0.1016;

	this.instance_3 = new lib.CachedBmp_230();
	this.instance_3.setTransform(-21.8,-6.2,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_229();
	this.instance_4.setTransform(72.8,-39.3,0.5,0.5);

	this.instance_5 = new lib.Group_1();
	this.instance_5.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance_5.alpha = 0.6016;

	this.instance_6 = new lib.CachedBmp_228();
	this.instance_6.setTransform(-98.35,-23.45,0.5,0.5);

	this.instance_7 = new lib.Path_1_22();
	this.instance_7.setTransform(2.55,-0.05,1,1,0,0,0,95.2,22.9);
	this.instance_7.alpha = 0.1016;

	this.instance_8 = new lib.CachedBmp_231();
	this.instance_8.setTransform(-98.35,-23.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]},1).to({state:[{t:this.instance_2},{t:this.instance_8}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-39.8,221,90.8);


(lib.S3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(230,245,218,0.8)").s().p("AxQGkIAAtHMAihAAAIAANHg");
	this.shape.setTransform(-6.45,3);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#3C3C3B").p("ALTDlI2lAAQhfAAhEhCQhDhEAAhfQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABfhDBEQhDBChgAAg");
	this.shape_1.setTransform(-2.575,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#3C3C3B").p("AgqAaIgwguQgFgGABgIQACgHAHgCQAIgDAGAGQADACAJAJIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgHAIAIIBUBUQAHAHgDAJQgCAHgHACQgIACgFgFIgIgKIgDADIhBBSQgDADADACIAKAKQAFAFAAAGQAAAGgEAEQgEAEgGAAQgGAAgFgFIgqgrIgCgDIhRBQQgHAIgIgDQgHgCgCgHQgDgHAFgGIBQhQg");
	this.shape_2.setTransform(86.3283,-25.7518);

	this.instance = new lib.Group_1();
	this.instance.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_1},{t:this.instance},{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_222();
	this.instance_1.setTransform(-98.4,-23.45,0.5,0.5);

	this.instance_2 = new lib.Path_7_6();
	this.instance_2.setTransform(2.6,-0.05,1,1,0,0,0,95.3,22.9);
	this.instance_2.alpha = 0.1016;

	this.instance_3 = new lib.CachedBmp_225();
	this.instance_3.setTransform(-25.55,-5.9,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_224();
	this.instance_4.setTransform(72.8,-39.3,0.5,0.5);

	this.instance_5 = new lib.Group_1();
	this.instance_5.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance_5.alpha = 0.6016;

	this.instance_6 = new lib.CachedBmp_228();
	this.instance_6.setTransform(-98.35,-23.45,0.5,0.5);

	this.instance_7 = new lib.Path_1_22();
	this.instance_7.setTransform(2.55,-0.05,1,1,0,0,0,95.2,22.9);
	this.instance_7.alpha = 0.1016;

	this.instance_8 = new lib.CachedBmp_226();
	this.instance_8.setTransform(-98.4,-23.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]},1).to({state:[{t:this.instance_2},{t:this.instance_8}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.9,-39.8,221,84.8);


(lib.S2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(230,245,218,0.8)").s().p("AxQGkIAAtHMAihAAAIAANHg");
	this.shape.setTransform(-0.5,-2);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#3C3C3B").p("ALTDlI2lAAQhfAAhEhCQhDhEAAhfQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABfhDBEQhDBChgAAg");
	this.shape_1.setTransform(-2.575,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#3C3C3B").p("AgqAaIgwguQgFgGABgIQACgHAHgCQAIgDAGAGQADACAJAJIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgHAIAIIBUBUQAHAHgDAJQgCAHgHACQgIACgFgFIgIgKIgDADIhBBSQgDADADACIAKAKQAFAFAAAGQAAAGgEAEQgEAEgGAAQgGAAgFgFIgqgrIgCgDIhRBQQgHAIgIgDQgHgCgCgHQgDgHAFgGIBQhQg");
	this.shape_2.setTransform(86.3283,-25.7518);

	this.instance = new lib.Group_1();
	this.instance.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_1},{t:this.instance},{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_217();
	this.instance_1.setTransform(-98.35,-23.45,0.5,0.5);

	this.instance_2 = new lib.Path_5_8();
	this.instance_2.setTransform(2.6,-0.05,1,1,0,0,0,95.3,22.9);
	this.instance_2.alpha = 0.1016;

	this.instance_3 = new lib.CachedBmp_220();
	this.instance_3.setTransform(-23.5,-15.4,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_219();
	this.instance_4.setTransform(72.8,-39.3,0.5,0.5);

	this.instance_5 = new lib.Group_1();
	this.instance_5.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance_5.alpha = 0.6016;

	this.instance_6 = new lib.CachedBmp_228();
	this.instance_6.setTransform(-98.35,-23.45,0.5,0.5);

	this.instance_7 = new lib.Path_1_22();
	this.instance_7.setTransform(2.55,-0.05,1,1,0,0,0,95.2,22.9);
	this.instance_7.alpha = 0.1016;

	this.instance_8 = new lib.CachedBmp_221();
	this.instance_8.setTransform(-98.35,-23.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]},1).to({state:[{t:this.instance_2},{t:this.instance_8}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111,-44,221,84);


(lib.S1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(230,245,218,0.8)").s().p("AxQGkIAAtHMAihAAAIAANHg");
	this.shape.setTransform(1.5,0.05);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#3C3C3B").p("ALTDlI2lAAQhfAAhEhCQhDhEAAhfQAAheBDhDQBEhEBfAAIWlAAQBfAABEBEQBDBDAABeQAABfhDBEQhDBChgAAg");
	this.shape_1.setTransform(-2.575,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#3C3C3B").p("AgqAaIgwguQgFgGABgIQACgHAHgCQAIgDAGAGQADACAJAJIADADIBWhGIgJgJQgEgFAAgGQABgGAFgEQAKgHAIAIIBUBUQAHAHgDAJQgCAHgHACQgIACgFgFIgIgKIgDADIhBBSQgDADADACIAKAKQAFAFAAAGQAAAGgEAEQgEAEgGAAQgGAAgFgFIgqgrIgCgDIhRBQQgHAIgIgDQgHgCgCgHQgDgHAFgGIBQhQg");
	this.shape_2.setTransform(86.3283,-25.7518);

	this.instance = new lib.Group_1();
	this.instance.setTransform(87.35,-26.65,1,1,0,0,0,13,13.1);
	this.instance.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_1},{t:this.instance},{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_214();
	this.instance_1.setTransform(-15.75,-15.4,0.5,0.5);

	this.instance_2 = new lib.Path_1_20();
	this.instance_2.setTransform(2.55,-0.05,1,1,0,0,0,95.2,22.9);
	this.instance_2.alpha = 0.1016;

	this.instance_3 = new lib.CachedBmp_215();
	this.instance_3.setTransform(-98.35,-23.45,0.5,0.5);

	this.instance_4 = new lib.Path_1_22();
	this.instance_4.setTransform(2.55,-0.05,1,1,0,0,0,95.2,22.9);
	this.instance_4.alpha = 0.1016;

	this.instance_5 = new lib.CachedBmp_216();
	this.instance_5.setTransform(-98.35,-23.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).to({state:[{t:this.instance_4},{t:this.instance_3}]},1).to({state:[{t:this.instance_2},{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109,-41.9,221,84);


(lib.popup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {F1:0,F5:1,F4:2,F10:3,F7:4,F3:5,F6:6,F2:7,F9:8,F8:9};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_159();
	this.instance.setTransform(-49.35,-25.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_158();
	this.instance_1.setTransform(-300.3,7.6,0.5,0.5);

	this.instance_2 = new lib.Group_2_1();
	this.instance_2.setTransform(-270.4,41.5,1,1,0,0,0,28.2,20.1);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.CachedBmp_157();
	this.instance_3.setTransform(-277.45,7.3,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_156();
	this.instance_4.setTransform(-405.05,21.55,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_155();
	this.instance_5.setTransform(-431.4,-36.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_154();
	this.instance_6.setTransform(-497.6,-58.2,0.5,0.5);

	this.instance_7 = new lib.Image_3();
	this.instance_7.setTransform(14.4,-50.75,1,1,0,0,0,520,16);
	this.instance_7.alpha = 0.3516;

	this.instance_8 = new lib.CachedBmp_165();
	this.instance_8.setTransform(-49.65,-25.4,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_164();
	this.instance_9.setTransform(-297.75,7.7,0.5,0.5);

	this.instance_10 = new lib.Group_2_7();
	this.instance_10.setTransform(-267.85,41.6,1,1,0,0,0,28.2,20.1);
	this.instance_10.alpha = 0.5;

	this.instance_11 = new lib.CachedBmp_163();
	this.instance_11.setTransform(-274.9,7.4,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_162();
	this.instance_12.setTransform(-408.2,21.65,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_161();
	this.instance_13.setTransform(-431.7,-36.25,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_160();
	this.instance_14.setTransform(-497.95,-58.1,0.5,0.5);

	this.instance_15 = new lib.Image_15();
	this.instance_15.setTransform(14.05,-50.65,1,1,0,0,0,520,16);
	this.instance_15.alpha = 0.3516;

	this.instance_16 = new lib.CachedBmp_171();
	this.instance_16.setTransform(-49.7,-25.45,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_170();
	this.instance_17.setTransform(-312.9,7.65,0.5,0.5);

	this.instance_18 = new lib.Group_2_2();
	this.instance_18.setTransform(-283.05,41.55,1,1,0,0,0,28.2,20.1);
	this.instance_18.alpha = 0.5;

	this.instance_19 = new lib.CachedBmp_169();
	this.instance_19.setTransform(-290.05,7.35,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_168();
	this.instance_20.setTransform(-414.95,22.15,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_167();
	this.instance_21.setTransform(-431.75,-36.3,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_166();
	this.instance_22.setTransform(-498,-58.15,0.5,0.5);

	this.instance_23 = new lib.Image_5();
	this.instance_23.setTransform(14,-50.7,1,1,0,0,0,520,16);
	this.instance_23.alpha = 0.3516;

	this.instance_24 = new lib.CachedBmp_177();
	this.instance_24.setTransform(-49.7,-25.5,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_176();
	this.instance_25.setTransform(-270.05,7.6,0.5,0.5);

	this.instance_26 = new lib.Group_2_8();
	this.instance_26.setTransform(-240.15,41.5,1,1,0,0,0,28.2,20.1);
	this.instance_26.alpha = 0.5;

	this.instance_27 = new lib.CachedBmp_175();
	this.instance_27.setTransform(-247.2,7.3,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_174();
	this.instance_28.setTransform(-436,21.4,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_173();
	this.instance_29.setTransform(-431.75,-36.35,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_172();
	this.instance_30.setTransform(-498,-58.2,0.5,0.5);

	this.instance_31 = new lib.Image_17();
	this.instance_31.setTransform(14,-50.75,1,1,0,0,0,520,16);
	this.instance_31.alpha = 0.3516;

	this.instance_32 = new lib.CachedBmp_183();
	this.instance_32.setTransform(-49.7,-25.45,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_182();
	this.instance_33.setTransform(-286.35,7.65,0.5,0.5);

	this.instance_34 = new lib.Group_2_6();
	this.instance_34.setTransform(-256.45,41.55,1,1,0,0,0,28.2,20.1);
	this.instance_34.alpha = 0.5;

	this.instance_35 = new lib.CachedBmp_181();
	this.instance_35.setTransform(-263.5,7.35,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_180();
	this.instance_36.setTransform(-419.7,21.45,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_179();
	this.instance_37.setTransform(-431.75,-36.3,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_178();
	this.instance_38.setTransform(-498,-58.15,0.5,0.5);

	this.instance_39 = new lib.Image_13();
	this.instance_39.setTransform(14,-50.7,1,1,0,0,0,520,16);
	this.instance_39.alpha = 0.3516;

	this.instance_40 = new lib.CachedBmp_189();
	this.instance_40.setTransform(-49.7,-25.45,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_188();
	this.instance_41.setTransform(-289.55,7.65,0.5,0.5);

	this.instance_42 = new lib.Group_2_3();
	this.instance_42.setTransform(-259.65,41.55,1,1,0,0,0,28.2,20.1);
	this.instance_42.alpha = 0.5;

	this.instance_43 = new lib.CachedBmp_187();
	this.instance_43.setTransform(-266.7,7.35,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_186();
	this.instance_44.setTransform(-416.5,21.45,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_185();
	this.instance_45.setTransform(-431.75,-36.3,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_184();
	this.instance_46.setTransform(-498,-58.15,0.5,0.5);

	this.instance_47 = new lib.Image_7();
	this.instance_47.setTransform(14,-50.7,1,1,0,0,0,520,16);
	this.instance_47.alpha = 0.3516;

	this.instance_48 = new lib.CachedBmp_195();
	this.instance_48.setTransform(-49.7,-25.45,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_194();
	this.instance_49.setTransform(-286.45,7.65,0.5,0.5);

	this.instance_50 = new lib.Group_2_0();
	this.instance_50.setTransform(-256.55,41.55,1,1,0,0,0,28.2,20.1);
	this.instance_50.alpha = 0.5;

	this.instance_51 = new lib.CachedBmp_193();
	this.instance_51.setTransform(-263.6,7.35,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_192();
	this.instance_52.setTransform(-419.6,22,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_191();
	this.instance_53.setTransform(-431.75,-36.3,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_190();
	this.instance_54.setTransform(-498,-58.15,0.5,0.5);

	this.instance_55 = new lib.Image_1_1();
	this.instance_55.setTransform(14,-50.7,1,1,0,0,0,520,16);
	this.instance_55.alpha = 0.3516;

	this.instance_56 = new lib.CachedBmp_201();
	this.instance_56.setTransform(-49.7,-25.4,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_200();
	this.instance_57.setTransform(-286.35,7.7,0.5,0.5);

	this.instance_58 = new lib.Group_2_5();
	this.instance_58.setTransform(-256.45,41.6,1,1,0,0,0,28.2,20.1);
	this.instance_58.alpha = 0.5;

	this.instance_59 = new lib.CachedBmp_199();
	this.instance_59.setTransform(-263.5,7.4,0.5,0.5);

	this.instance_60 = new lib.CachedBmp_198();
	this.instance_60.setTransform(-421.8,22.05,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_197();
	this.instance_61.setTransform(-431.75,-36.25,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_196();
	this.instance_62.setTransform(-498,-58.1,0.5,0.5);

	this.instance_63 = new lib.Image_11();
	this.instance_63.setTransform(14,-50.65,1,1,0,0,0,520,16);
	this.instance_63.alpha = 0.3516;

	this.instance_64 = new lib.CachedBmp_207();
	this.instance_64.setTransform(-49.7,-25.4,0.5,0.5);

	this.instance_65 = new lib.CachedBmp_206();
	this.instance_65.setTransform(-290.5,7.7,0.5,0.5);

	this.instance_66 = new lib.Group_2_4();
	this.instance_66.setTransform(-260.6,41.6,1,1,0,0,0,28.2,20.1);
	this.instance_66.alpha = 0.5;

	this.instance_67 = new lib.CachedBmp_205();
	this.instance_67.setTransform(-267.6,7.4,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_204();
	this.instance_68.setTransform(-415.6,19.35,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_203();
	this.instance_69.setTransform(-431.75,-36.25,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_202();
	this.instance_70.setTransform(-498,-58.1,0.5,0.5);

	this.instance_71 = new lib.Image_9();
	this.instance_71.setTransform(14,-50.65,1,1,0,0,0,520,16);
	this.instance_71.alpha = 0.3516;

	this.instance_72 = new lib.CachedBmp_213();
	this.instance_72.setTransform(-49.7,-25.4,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_212();
	this.instance_73.setTransform(-279.8,7.7,0.5,0.5);

	this.instance_74 = new lib.Group_2_1_1();
	this.instance_74.setTransform(-249.95,41.6,1,1,0,0,0,28.2,20.1);
	this.instance_74.alpha = 0.5;

	this.instance_75 = new lib.CachedBmp_211();
	this.instance_75.setTransform(-256.95,7.4,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_210();
	this.instance_76.setTransform(-426.25,22.05,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_209();
	this.instance_77.setTransform(-431.75,-36.25,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_208();
	this.instance_78.setTransform(-498,-58.1,0.5,0.5);

	this.instance_79 = new lib.Image_3_1();
	this.instance_79.setTransform(14,-50.65,1,1,0,0,0,520,16);
	this.instance_79.alpha = 0.3516;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8}]},1).to({state:[{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16}]},1).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24}]},1).to({state:[{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32}]},1).to({state:[{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40}]},1).to({state:[{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48}]},1).to({state:[{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56}]},1).to({state:[{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64}]},1).to({state:[{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-506,-66.7,1040.4,150.5);


(lib.popAll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_10 = function() {
		this.stop();
	}
	this.frame_22 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10).call(this.frame_10).wait(12).call(this.frame_22).wait(1));

	// PopUp_copy
	this.pop = new lib.popup();
	this.pop.name = "pop";
	this.pop.setTransform(633.4,785.8);

	this.timeline.addTween(cjs.Tween.get(this.pop).wait(1).to({regX:14.2,regY:8.5,x:647.6,y:786.85},0).wait(1).to({y:771.4},0).wait(1).to({y:747.95},0).wait(1).to({y:724.5},0).wait(1).to({y:693.45},0).wait(1).to({y:662.4},0).wait(1).to({y:628.4},0).wait(1).to({y:633.05},0).wait(1).to({y:637.7},0).wait(1).to({y:642.4},0).wait(1).to({y:641.15},0).wait(1).to({y:639.9},0).wait(1).to({y:638.65},0).wait(1).to({y:637.4},0).wait(1).to({y:634.4},0).wait(1).to({y:631.4},0).wait(1).to({y:628.4},0).wait(1).to({y:635.45},0).wait(1).to({y:654.35},0).wait(1).to({y:688},0).wait(1).to({y:735.2},0).wait(1).to({y:794.3},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(127.8,553.2,1040,316.29999999999995);


(lib.aboutfront = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_151();
	this.instance.setTransform(458.55,-264.4,0.5,0.5);

	this.instance_1 = new lib.Image_0_2();
	this.instance_1.setTransform(473,-247.95,1,1,0,0,0,24.5,24.5);
	this.instance_1.alpha = 0.75;
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_150();
	this.instance_2.setTransform(-133.25,161.85,0.5,0.5);

	this.instance_3 = new lib.Image();
	this.instance_3.setTransform(-76.85,25.7,0.4259,0.4259);

	this.instance_4 = new lib.CachedBmp_149();
	this.instance_4.setTransform(-504.5,-281.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aboutfront, new cjs.Rectangle(-504.5,-281.7,1009,563.5), null);


(lib.about_closebut = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3C3C3B").s().p("Ah2B3QgDgCAAgFQAAgDADgDIDgjgQACgEAFAAQAEAAACAEQAEACAAAEQAAAFgEACIjgDgQgDADgDAAQgFAAgCgDg");
	this.shape.setTransform(-2.2,-4.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3C3C3B").s().p("ABqB3IjgjgQgDgCAAgFQAAgEADgCQACgEAFAAQADAAADAEIDgDgQAEADAAADQAAAFgEACQgDADgDAAQgFAAgCgDg");
	this.shape_1.setTransform(-2.2,-4.2);

	this.instance = new lib.Image_0_2();
	this.instance.setTransform(0,0,1,1,0,0,0,24.5,24.5);
	this.instance.alpha = 0.75;
	this.instance.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.about_closebut, new cjs.Rectangle(-24.5,-24.5,49,49), null);


(lib.About = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"over":1};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_147();
	this.instance.setTransform(-62.85,-23.45,0.5,0.5);

	this.instance_1 = new lib.Path_9_3_1();
	this.instance_1.setTransform(3.05,-0.05,1,1,0,0,0,59.4,22.9);
	this.instance_1.alpha = 0.1016;

	this.instance_2 = new lib.CachedBmp_148();
	this.instance_2.setTransform(-62.85,-23.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_1},{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.8,-23.4,125.19999999999999,47);


(lib.Group_1_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_26();
	this.instance.setTransform(33.75,60.6,1,1,0,0,0,2,13.5);

	this.instance_1 = new lib.Path_1_12();
	this.instance_1.setTransform(27.95,55.7,1,1,0,0,0,5,10);

	this.instance_2 = new lib.Path_2_4();
	this.instance_2.setTransform(21.95,50.6,1,1,0,0,0,8.5,8);

	this.instance_3 = new lib.Path_3_4_1();
	this.instance_3.setTransform(18.8,44.7,1,1,0,0,0,10,4.5);

	this.instance_4 = new lib.Path_4_4();
	this.instance_4.setTransform(14.5,37.25,1,1,0,0,0,14.5,1);

	this.instance_5 = new lib.Path_5_4();
	this.instance_5.setTransform(16.95,29.55,1,1,0,0,0,12.5,4.5);

	this.instance_6 = new lib.Path_6_3_1();
	this.instance_6.setTransform(20.1,21.85,1,1,0,0,0,11,9);

	this.instance_7 = new lib.Path_7_2_1();
	this.instance_7.setTransform(27.75,19.4,1,1,0,0,0,6.5,9.5);

	this.instance_8 = new lib.Path_8_1_1();
	this.instance_8.setTransform(34.7,14,1,1,0,0,0,3,14);

	this.instance_9 = new lib.Path_9_1_1();
	this.instance_9.setTransform(43,15.15,1,1,0,0,0,3,13);

	this.instance_10 = new lib.Path_10_2_1();
	this.instance_10.setTransform(50.55,17.2,1,1,0,0,0,7,12.5);

	this.instance_11 = new lib.Path_11_1_1();
	this.instance_11.setTransform(53.05,25.1,1,1,0,0,0,7,7.5);

	this.instance_12 = new lib.Path_12_1_1();
	this.instance_12.setTransform(62.15,32.75,1,1,0,0,0,14,2.5);

	this.instance_13 = new lib.Path_13_1_1();
	this.instance_13.setTransform(62.4,38.25,1,1,0,0,0,14.5,0.5);

	this.instance_14 = new lib.Path_14_1_1();
	this.instance_14.setTransform(60.05,46.05,1,1,0,0,0,13,4.5);

	this.instance_15 = new lib.Path_15_1_1();
	this.instance_15.setTransform(56.1,53.4,1,1,0,0,0,11,9);

	this.instance_16 = new lib.Path_16_0_1();
	this.instance_16.setTransform(48.85,55.9,1,1,0,0,0,6.5,9.5);

	this.instance_17 = new lib.Path_17_0_1();
	this.instance_17.setTransform(42.05,61.35,1,1,0,0,0,3,14);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_11, new cjs.Rectangle(0,0,76.9,75.4), null);


(lib.Group_1_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_37();
	this.instance.setTransform(38.7,68.8,1,1,0,0,0,2.5,15);

	this.instance_1 = new lib.Path_1_25();
	this.instance_1.setTransform(31.65,63.65,1,1,0,0,0,5.5,11.5);

	this.instance_2 = new lib.Path_2_12();
	this.instance_2.setTransform(24.85,57.65,1,1,0,0,0,9.5,9);

	this.instance_3 = new lib.Path_3_10();
	this.instance_3.setTransform(21.5,51.4,1,1,0,0,0,11.5,5.5);

	this.instance_4 = new lib.Path_4_10();
	this.instance_4.setTransform(16.5,42.4,1,1,0,0,0,16.5,1);

	this.instance_5 = new lib.Path_5_10();
	this.instance_5.setTransform(19.05,33.6,1,1,0,0,0,14,5);

	this.instance_6 = new lib.Path_6_0_3();
	this.instance_6.setTransform(22.85,25.15,1,1,0,0,0,12.5,10.5);

	this.instance_7 = new lib.Path_7_8();
	this.instance_7.setTransform(31.7,22.3,1,1,0,0,0,7.5,11);

	this.instance_8 = new lib.Path_8_7();
	this.instance_8.setTransform(39.65,16,1,1,0,0,0,3.5,16);

	this.instance_9 = new lib.Path_9_6();
	this.instance_9.setTransform(49.15,17.45,1,1,0,0,0,3.5,15);

	this.instance_10 = new lib.Path_10_6();
	this.instance_10.setTransform(57.75,19.85,1,1,0,0,0,8,14.5);

	this.instance_11 = new lib.Path_11_3();
	this.instance_11.setTransform(60.55,28.55,1,1,0,0,0,8,8.5);

	this.instance_12 = new lib.Path_12_4();
	this.instance_12.setTransform(71,37.55,1,1,0,0,0,16,3);

	this.instance_13 = new lib.Path_13_3();
	this.instance_13.setTransform(71.2,43.6,1,1,0,0,0,16.5,0.5);

	this.instance_14 = new lib.Path_14_4();
	this.instance_14.setTransform(68.2,52.45,1,1,0,0,0,14.5,5);

	this.instance_15 = new lib.Path_15_4();
	this.instance_15.setTransform(64,61.2,1,1,0,0,0,12.5,10.5);

	this.instance_16 = new lib.Path_16_3();
	this.instance_16.setTransform(55.3,63.5,1,1,0,0,0,7,10.5);

	this.instance_17 = new lib.Path_17_4();
	this.instance_17.setTransform(48.05,70.05,1,1,0,0,0,3.5,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_0, new cjs.Rectangle(0,0,87.7,86.1), null);


(lib.aboutPop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.aboutC = new lib.about_closebut();
	this.aboutC.name = "aboutC";
	this.aboutC.setTransform(473,-247.95);

	this.timeline.addTween(cjs.Tween.get(this.aboutC).wait(1));

	// Layer_1
	this.instance = new lib.aboutfront();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(161,161,129,0.498)").s().p("Eho1A5HMAAAh03MDRrAAAMAAAB3hg");
	this.shape.setTransform(13.05,14.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aboutPop, new cjs.Rectangle(-657.9,-367.9,1341.9,764.9), null);


(lib.F1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_52();
	this.instance.setTransform(-67.95,-40.55,0.5,0.5);

	this.instance_1 = new lib.Path_24();
	this.instance_1.setTransform(-19.3,16.3);

	this.instance_2 = new lib.Path_1_7();
	this.instance_2.setTransform(18.2,-30.2);

	this.instance_3 = new lib.Path_2_1_1();
	this.instance_3.setTransform(-24.55,-10.8);

	this.instance_4 = new lib.Path_3_1_1();
	this.instance_4.setTransform(0.7,-23.35);

	this.instance_5 = new lib.Path_4_1_1();
	this.instance_5.setTransform(13.25,-20.2);

	this.instance_6 = new lib.Path_5_1_1();
	this.instance_6.setTransform(24.6,-23.05);

	this.instance_7 = new lib.Path_6_0_2();
	this.instance_7.setTransform(-6.7,-11.95);

	this.instance_8 = new lib.Path_7_0_3();
	this.instance_8.setTransform(-15.6,2.65);

	this.instance_9 = new lib.Path_8_0_2();
	this.instance_9.setTransform(0.7,5.2);

	this.instance_10 = new lib.Path_9_0_3();
	this.instance_10.setTransform(-1.45,17.05);

	this.instance_11 = new lib.Path_10_1_1();
	this.instance_11.setTransform(15.3,2.6);

	this.instance_12 = new lib.Path_11_0_1();
	this.instance_12.setTransform(5.85,-8.8);

	this.instance_13 = new lib.Path_12_0_2();
	this.instance_13.setTransform(-48.25,4);

	this.instance_14 = new lib.Path_13_0_1();
	this.instance_14.setTransform(-30.2,1);

	this.instance_15 = new lib.Path_14_0_1();
	this.instance_15.setTransform(17.2,-11.65);

	this.instance_16 = new lib.Path_15_0_1();
	this.instance_16.setTransform(-34.85,11.45);

	this.instance_17 = new lib.CachedBmp_51();
	this.instance_17.setTransform(-65.3,-41.4,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_50();
	this.instance_18.setTransform(-32.5,-70,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_49();
	this.instance_19.setTransform(-25.05,49.35,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_56();
	this.instance_20.setTransform(-79.5,-37.3,0.5,0.5);

	this.instance_21 = new lib.Path();
	this.instance_21.setTransform(-22.9,28.35);

	this.instance_22 = new lib.Path_1_1();
	this.instance_22.setTransform(20.9,-25.9);

	this.instance_23 = new lib.Path_2_3();
	this.instance_23.setTransform(-29,-3.3);

	this.instance_24 = new lib.Path_3_4();
	this.instance_24.setTransform(0.5,-17.9);

	this.instance_25 = new lib.Path_4_3();
	this.instance_25.setTransform(15.15,-14.25);

	this.instance_26 = new lib.Path_5_3();
	this.instance_26.setTransform(28.35,-17.55);

	this.instance_27 = new lib.Path_6_3();
	this.instance_27.setTransform(-8.15,-4.6);

	this.instance_28 = new lib.Path_7_2();
	this.instance_28.setTransform(-18.6,12.4);

	this.instance_29 = new lib.Path_8_4();
	this.instance_29.setTransform(0.45,15.4);

	this.instance_30 = new lib.Path_9_4();
	this.instance_30.setTransform(-2.05,29.25);

	this.instance_31 = new lib.Path_10_2();
	this.instance_31.setTransform(17.55,12.35);

	this.instance_32 = new lib.Path_11_2();
	this.instance_32.setTransform(6.5,-0.95);

	this.instance_33 = new lib.Path_12_2();
	this.instance_33.setTransform(-56.7,13.95);

	this.instance_34 = new lib.Path_13_2();
	this.instance_34.setTransform(-35.6,10.45);

	this.instance_35 = new lib.Path_14_3();
	this.instance_35.setTransform(19.7,-4.25);

	this.instance_36 = new lib.Path_15_3();
	this.instance_36.setTransform(-41,22.7);

	this.instance_37 = new lib.CachedBmp_55();
	this.instance_37.setTransform(-76.55,-72.1,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_54();
	this.instance_38.setTransform(91.3,-65.1,0.5,0.5);

	this.instance_39 = new lib.Group_1_9();
	this.instance_39.setTransform(105.85,-52.45,1,1,0,0,0,13,13.1);
	this.instance_39.alpha = 0.6016;

	this.instance_40 = new lib.CachedBmp_53();
	this.instance_40.setTransform(-29.6,66.9,0.5,0.5);

	this.instance_41 = new lib.Group_8();
	this.instance_41.setTransform(-118,-110);

	this.instance_42 = new lib.F1over();
	this.instance_42.filters = [new cjs.ColorFilter(0.4, 0.4, 0.4, 1, 138, 147, 130.8, 0)];
	this.instance_42.cache(-70,-72,140,144);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20}]},1).to({state:[{t:this.instance_42}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-118,-110,236.9,200.9);


(lib.F10over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_48();
	this.instance.setTransform(-59.2,-68.8,0.5,0.5);

	this.instance_1 = new lib.Path_32();
	this.instance_1.setTransform(-36.1,-46.75,1,1,0,0,0,6.5,14);

	this.instance_2 = new lib.Path_1_18();
	this.instance_2.setTransform(-19.3,7.8,1,1,0,0,0,7,14);

	this.instance_3 = new lib.Path_2_10();
	this.instance_3.setTransform(-28.6,-20.25,1,1,0,0,0,2.5,35.5);

	this.instance_4 = new lib.Path_3_8();
	this.instance_4.setTransform(-28.95,-20.6,1,1,0,0,0,3.8,37.1);
	this.instance_4.alpha = 0.3906;

	this.instance_5 = new lib.Path_4_8();
	this.instance_5.setTransform(-28.95,-20.6,1,1,0,0,0,5.6,37.1);
	this.instance_5.alpha = 0.5;

	this.instance_6 = new lib.CachedBmp_47();
	this.instance_6.setTransform(-53.7,-64.6,0.5,0.5);

	this.instance_7 = new lib.Path_6_7();
	this.instance_7.setTransform(-29.55,-19.6,1,1,0,0,0,27.2,48.8);
	this.instance_7.alpha = 0.4102;

	this.instance_8 = new lib.CachedBmp_46();
	this.instance_8.setTransform(-57.2,-68.8,0.5,0.5);

	this.instance_9 = new lib.Path_1_16();
	this.instance_9.setTransform(-29.5,14.7,1,1,0,0,0,5,15.5);

	this.instance_10 = new lib.Path_2_8();
	this.instance_10.setTransform(-15.75,14.7,1,1,0,0,0,5,15.5);

	this.instance_11 = new lib.CachedBmp_45();
	this.instance_11.setTransform(-39.35,-40.25,0.5,0.5);

	this.instance_12 = new lib.Path_31_1();
	this.instance_12.setTransform(10.45,-4.4,1,1,0,0,0,48.5,33.8);
	this.instance_12.alpha = 0.4102;

	this.instance_13 = new lib.Path_29_1();
	this.instance_13.setTransform(24.25,-4.8,1,1,0,0,0,9.5,3.5);

	this.instance_14 = new lib.Path_1_14();
	this.instance_14.setTransform(-14.4,15.35,1,1,0,0,0,8.5,4.5);

	this.instance_15 = new lib.Path_2_6();
	this.instance_15.setTransform(-16.75,-11.75,1,1,0,0,0,6.5,5);

	this.instance_16 = new lib.Path_3_6();
	this.instance_16.setTransform(1.6,-3.9,1,1,0,0,0,8,5.5);

	this.instance_17 = new lib.Path_4_6();
	this.instance_17.setTransform(9.75,14.15,1,1,0,0,0,10.5,4.5);

	this.instance_18 = new lib.Path_5_6();
	this.instance_18.setTransform(-20.85,7.4,1,1,0,0,0,7.5,6.5);

	this.instance_19 = new lib.Path_6_5();
	this.instance_19.setTransform(9.45,-20.4,1,1,0,0,0,9,4.5);

	this.instance_20 = new lib.Path_7_4();
	this.instance_20.setTransform(39.75,-2.7,1,1,0,0,0,8,6.5);

	this.instance_21 = new lib.CachedBmp_44();
	this.instance_21.setTransform(-38.35,-38.6,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_43();
	this.instance_22.setTransform(-17.95,51.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F10over, new cjs.Rectangle(-59.2,-68.8,118.4,137), null);


(lib.F9over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_42();
	this.instance.setTransform(-77.5,-60.15,0.5,0.5);

	this.instance_1 = new lib.Path_25();
	this.instance_1.setTransform(-44,-10.9);

	this.instance_2 = new lib.Path_1_10();
	this.instance_2.setTransform(16.95,-38.45,1,1,0,0,0,12.5,11.5);

	this.instance_3 = new lib.Path_2_2_2();
	this.instance_3.setTransform(-52.55,-36.65,1,1,0,0,0,12.5,11.5);

	this.instance_4 = new lib.Path_3_2_2();
	this.instance_4.setTransform(-46.75,5.05,1,1,0,0,0,10,9.5);

	this.instance_5 = new lib.Path_4_2_1();
	this.instance_5.setTransform(-51.6,7.5,1,1,0,0,0,12.5,11.5);

	this.instance_6 = new lib.Path_5_2_1();
	this.instance_6.setTransform(12.35,3.25,1,1,0,0,0,10,9.5);

	this.instance_7 = new lib.Path_6_1_2();
	this.instance_7.setTransform(17.9,5.7,1,1,0,0,0,12.5,11.5);

	this.instance_8 = new lib.Path_7_1_1();
	this.instance_8.setTransform(-1.2,-12.4);

	this.instance_9 = new lib.CachedBmp_41();
	this.instance_9.setTransform(-72.8,-62.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_40();
	this.instance_10.setTransform(-34.4,-64.3,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_121();
	this.instance_11.setTransform(18.35,-57,0.5,0.5);

	this.instance_12 = new lib.Path_1_8();
	this.instance_12.setTransform(49.85,-1.5,1,1,0,0,0,12,19);

	this.instance_13 = new lib.CachedBmp_38();
	this.instance_13.setTransform(-34.7,-64.55,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_37();
	this.instance_14.setTransform(-34.6,46.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F9over, new cjs.Rectangle(-77.5,-64.5,154.8,129), null);


(lib.F8over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(-65.85,-68.3,0.5,0.5);

	this.instance_1 = new lib.Group_1_11();
	this.instance_1.setTransform(-17.25,-18.75,1,1,0,0,0,38.5,37.6);
	this.instance_1.alpha = 0.6992;

	this.instance_2 = new lib.CachedBmp_35();
	this.instance_2.setTransform(-63.85,-69.55,0.5,0.5);

	this.instance_3 = new lib.Group_0();
	this.instance_3.setTransform(41.65,0.25,1,1,0,0,0,15.7,22.8);
	this.instance_3.alpha = 0.3984;

	this.instance_4 = new lib.CachedBmp_34();
	this.instance_4.setTransform(-31.4,-70.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_33();
	this.instance_5.setTransform(-34,43.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F8over, new cjs.Rectangle(-65.8,-70,131.89999999999998,139.5), null);


(lib.F7over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_32();
	this.instance.setTransform(-68.4,-69.05,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_104();
	this.instance_1.setTransform(-31.1,-68.9,0.5,0.5);

	this.instance_2 = new lib.Group();
	this.instance_2.setTransform(41.55,-4.6,1,1,0,0,0,15.6,22.8);
	this.instance_2.alpha = 0.3984;

	this.instance_3 = new lib.CachedBmp_103();
	this.instance_3.setTransform(-32.6,-70.4,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_29();
	this.instance_4.setTransform(-37.15,47.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F7over, new cjs.Rectangle(-68.4,-70.4,136.8,140.9), null);


(lib.F6over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_28();
	this.instance.setTransform(0.05,-30.4,1,1,0,0,0,14.1,25.6);
	this.instance.alpha = 0.3984;

	this.instance_1 = new lib.CachedBmp_28();
	this.instance_1.setTransform(-64.45,-70.45,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_27();
	this.instance_2.setTransform(-36.75,-60.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_26();
	this.instance_3.setTransform(-17.1,47.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F6over, new cjs.Rectangle(-64.4,-70.4,127.2,140.8), null);


(lib.F5over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_25();
	this.instance.setTransform(-72.55,-77.75,0.5,0.5);

	this.instance_1 = new lib.Path_1_6();
	this.instance_1.setTransform(-29.95,-18.25,1,1,0,0,0,27.8,33.1);
	this.instance_1.alpha = 0.3008;

	this.instance_2 = new lib.CachedBmp_24();
	this.instance_2.setTransform(-71,-66.35,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_23();
	this.instance_3.setTransform(-38.25,-78.3,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_22();
	this.instance_4.setTransform(-36.45,61.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F5over, new cjs.Rectangle(-72.5,-78.3,144.3,156.6), null);


(lib.F4over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_83();
	this.instance.setTransform(-71.75,-68.35,0.5,0.5);

	this.instance_1 = new lib.Path_1_2_1();
	this.instance_1.setTransform(-2.05,-27.25);

	this.instance_2 = new lib.Path_2_1();
	this.instance_2.setTransform(5.85,-35.3);

	this.instance_3 = new lib.Path_3_2();
	this.instance_3.setTransform(-6.8,-36);

	this.instance_4 = new lib.Path_4_1();
	this.instance_4.setTransform(-7.6,-9.2);

	this.instance_5 = new lib.Path_5_2();
	this.instance_5.setTransform(2.05,-8.7);

	this.instance_6 = new lib.Path_6_2();
	this.instance_6.setTransform(-2.8,-17.75);

	this.instance_7 = new lib.Path_7_1();
	this.instance_7.setTransform(-20.25,8.65);

	this.instance_8 = new lib.Path_8_2();
	this.instance_8.setTransform(-16.65,1.05);

	this.instance_9 = new lib.Path_9_2();
	this.instance_9.setTransform(-8.6,2.15);

	this.instance_10 = new lib.Path_10_0_2();
	this.instance_10.setTransform(-44.75,0.35);

	this.instance_11 = new lib.Path_11_1();
	this.instance_11.setTransform(-37.4,-1.95);

	this.instance_12 = new lib.Path_12_1();
	this.instance_12.setTransform(-34.7,4.85);

	this.instance_13 = new lib.Path_13_1();
	this.instance_13.setTransform(-49.6,-27.25);

	this.instance_14 = new lib.Path_14_2();
	this.instance_14.setTransform(-49.6,-6.25);

	this.instance_15 = new lib.Path_15_2();
	this.instance_15.setTransform(-47.35,-16.35);

	this.instance_16 = new lib.Path_16_2();
	this.instance_16.setTransform(-37.65,-40.2);

	this.instance_17 = new lib.Path_17_3();
	this.instance_17.setTransform(-46.25,-43.9);

	this.instance_18 = new lib.Path_18_2();
	this.instance_18.setTransform(-43.9,-35.05);

	this.instance_19 = new lib.Path_19_1();
	this.instance_19.setTransform(-18.05,-49.5);

	this.instance_20 = new lib.Path_20_1();
	this.instance_20.setTransform(-16.05,-41.2);

	this.instance_21 = new lib.Path_21_1();
	this.instance_21.setTransform(-27.95,-49.5);

	this.instance_22 = new lib.CachedBmp_82();
	this.instance_22.setTransform(-34.55,-31.4,0.5,0.5);

	this.instance_23 = new lib.Path_23();
	this.instance_23.setTransform(-23.5,-17.8,1,1,0,0,0,24.9,29.8);
	this.instance_23.alpha = 0.5;

	this.instance_24 = new lib.CachedBmp_19();
	this.instance_24.setTransform(-68.3,-68.8,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_80();
	this.instance_25.setTransform(-27,-69.3,0.5,0.5);

	this.instance_26 = new lib.Path_1_1_1();
	this.instance_26.setTransform(28.95,6.2,1,1,0,0,0,28.2,12.8);
	this.instance_26.alpha = 0.1016;

	this.instance_27 = new lib.CachedBmp_79();
	this.instance_27.setTransform(-26.95,-71.6,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_16();
	this.instance_28.setTransform(-15.4,51.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F4over, new cjs.Rectangle(-71.7,-71.6,143.7,143.5), null);


(lib.F3over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_15();
	this.instance.setTransform(-53.85,-40.7,0.5,0.5);

	this.instance_1 = new lib.Path_34();
	this.instance_1.setTransform(1.5,-8.6,1,1,0,0,0,18.8,36.1);
	this.instance_1.alpha = 0.3008;

	this.instance_2 = new lib.Path_1_0_3();
	this.instance_2.setTransform(-38.3,-9.5,1,1,0,0,0,18.7,35.7);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.CachedBmp_14();
	this.instance_3.setTransform(-64.7,-78.7,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_70();
	this.instance_4.setTransform(-31.45,-75.7,0.5,0.5);

	this.instance_5 = new lib.Path_1_21();
	this.instance_5.setTransform(45.95,-16.05,1,1,0,0,0,9.1,28.8);
	this.instance_5.alpha = 0.2617;

	this.instance_6 = new lib.CachedBmp_69();
	this.instance_6.setTransform(-30.95,-77,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_11();
	this.instance_7.setTransform(-19.35,60.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F3over, new cjs.Rectangle(-64.7,-78.7,129.8,157.60000000000002), null);


(lib.F2over = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(-64.95,-72.95,0.5,0.5);

	this.instance_1 = new lib.Path_22();
	this.instance_1.setTransform(-31.55,-17.65,1,1,0,0,0,3.8,15.5);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(-18.8,-65.05,1,1,0,0,0,2.7,6.8);
	this.instance_2.alpha = 0.1484;

	this.instance_3 = new lib.Path_2_0_2();
	this.instance_3.setTransform(-5.15,-17.45,1,1,0,0,0,8.6,16.1);
	this.instance_3.alpha = 0.1484;

	this.instance_4 = new lib.Path_3_0_2();
	this.instance_4.setTransform(-50.95,-8.35);

	this.instance_5 = new lib.Path_4_0_3();
	this.instance_5.setTransform(-8.1,-8.8);

	this.instance_6 = new lib.Path_5_0_3();
	this.instance_6.setTransform(-24.8,-42.05);

	this.instance_7 = new lib.CachedBmp_9();
	this.instance_7.setTransform(-63,-72.45,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_8();
	this.instance_8.setTransform(-27.2,-74.25,0.5,0.5);

	this.instance_9 = new lib.Path_0_2();
	this.instance_9.setTransform(46.3,-20.85,1,1,0,0,0,8.8,27.9);
	this.instance_9.alpha = 0.2617;

	this.instance_10 = new lib.Path_1_3();
	this.instance_10.setTransform(45.55,-65.55,1,1,0,0,0,1.5,8);

	this.instance_11 = new lib.CachedBmp_7();
	this.instance_11.setTransform(-24.45,-74.7,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_6();
	this.instance_12.setTransform(-17.3,54.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F2over, new cjs.Rectangle(-64.9,-74.7,130,148.9), null);


(lib.F10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_136();
	this.instance.setTransform(-59.2,-68.8,0.5,0.5);

	this.instance_1 = new lib.Path_32();
	this.instance_1.setTransform(-36.1,-46.75,1,1,0,0,0,6.5,14);

	this.instance_2 = new lib.Path_1_18();
	this.instance_2.setTransform(-19.3,7.8,1,1,0,0,0,7,14);

	this.instance_3 = new lib.Path_2_10();
	this.instance_3.setTransform(-28.6,-20.25,1,1,0,0,0,2.5,35.5);

	this.instance_4 = new lib.Path_3_8();
	this.instance_4.setTransform(-28.95,-20.6,1,1,0,0,0,3.8,37.1);
	this.instance_4.alpha = 0.3906;

	this.instance_5 = new lib.Path_4_8();
	this.instance_5.setTransform(-28.95,-20.6,1,1,0,0,0,5.6,37.1);
	this.instance_5.alpha = 0.5;

	this.instance_6 = new lib.CachedBmp_135();
	this.instance_6.setTransform(-53.7,-64.6,0.5,0.5);

	this.instance_7 = new lib.Path_6_7();
	this.instance_7.setTransform(-29.55,-19.6,1,1,0,0,0,27.2,48.8);
	this.instance_7.alpha = 0.4102;

	this.instance_8 = new lib.CachedBmp_134();
	this.instance_8.setTransform(-57.2,-68.8,0.5,0.5);

	this.instance_9 = new lib.Path_1_16();
	this.instance_9.setTransform(-29.5,14.7,1,1,0,0,0,5,15.5);

	this.instance_10 = new lib.Path_2_8();
	this.instance_10.setTransform(-15.75,14.7,1,1,0,0,0,5,15.5);

	this.instance_11 = new lib.CachedBmp_133();
	this.instance_11.setTransform(-39.35,-40.25,0.5,0.5);

	this.instance_12 = new lib.Path_31_1();
	this.instance_12.setTransform(10.45,-4.4,1,1,0,0,0,48.5,33.8);
	this.instance_12.alpha = 0.4102;

	this.instance_13 = new lib.Path_29_1();
	this.instance_13.setTransform(24.25,-4.8,1,1,0,0,0,9.5,3.5);

	this.instance_14 = new lib.Path_1_14();
	this.instance_14.setTransform(-14.4,15.35,1,1,0,0,0,8.5,4.5);

	this.instance_15 = new lib.Path_2_6();
	this.instance_15.setTransform(-16.75,-11.75,1,1,0,0,0,6.5,5);

	this.instance_16 = new lib.Path_3_6();
	this.instance_16.setTransform(1.6,-3.9,1,1,0,0,0,8,5.5);

	this.instance_17 = new lib.Path_4_6();
	this.instance_17.setTransform(9.75,14.15,1,1,0,0,0,10.5,4.5);

	this.instance_18 = new lib.Path_5_6();
	this.instance_18.setTransform(-20.85,7.4,1,1,0,0,0,7.5,6.5);

	this.instance_19 = new lib.Path_6_5();
	this.instance_19.setTransform(9.45,-20.4,1,1,0,0,0,9,4.5);

	this.instance_20 = new lib.Path_7_4();
	this.instance_20.setTransform(39.75,-2.7,1,1,0,0,0,8,6.5);

	this.instance_21 = new lib.CachedBmp_132();
	this.instance_21.setTransform(-38.35,-38.6,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_131();
	this.instance_22.setTransform(-17.95,51.2,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_142();
	this.instance_23.setTransform(67.5,-86.55,0.5,0.5);

	this.instance_24 = new lib.Group_1_10();
	this.instance_24.setTransform(82.05,-73.9,1,1,0,0,0,13,13.1);
	this.instance_24.alpha = 0.6016;

	this.instance_25 = new lib.CachedBmp_141();
	this.instance_25.setTransform(-69.9,-90.8,0.5,0.5);

	this.instance_26 = new lib.Path_1_1_2();
	this.instance_26.setTransform(-42.3,-64.4,1,1,0,0,0,8,17);

	this.instance_27 = new lib.Path_2_1_2();
	this.instance_27.setTransform(-23,0.15,1,1,0,0,0,8,17);

	this.instance_28 = new lib.Path_3_1_2();
	this.instance_28.setTransform(-34.15,-33.5,1,1,0,0,0,2.5,42);

	this.instance_29 = new lib.Path_4_1_2();
	this.instance_29.setTransform(-34.1,-33.85,1,1,0,0,0,4.5,43.9);
	this.instance_29.alpha = 0.3906;

	this.instance_30 = new lib.Path_5_1_2();
	this.instance_30.setTransform(-34.1,-33.85,1,1,0,0,0,6.7,43.9);
	this.instance_30.alpha = 0.5;

	this.instance_31 = new lib.CachedBmp_140();
	this.instance_31.setTransform(-63.35,-85.85,0.5,0.5);

	this.instance_32 = new lib.Path_7_1_2();
	this.instance_32.setTransform(-34.85,-32.75,1,1,0,0,0,32.2,57.7);
	this.instance_32.alpha = 0.4102;

	this.instance_33 = new lib.CachedBmp_139();
	this.instance_33.setTransform(-67.5,-90.8,0.5,0.5);

	this.instance_34 = new lib.Path_9_7();
	this.instance_34.setTransform(-34.7,7.55,1,1,0,0,0,6,18);

	this.instance_35 = new lib.Path_10_7();
	this.instance_35.setTransform(-18.4,7.55,1,1,0,0,0,6,18);

	this.instance_36 = new lib.CachedBmp_138();
	this.instance_36.setTransform(-46.4,-57.1,0.5,0.5);

	this.instance_37 = new lib.Path_12_5();
	this.instance_37.setTransform(12.5,-14.8,1,1,0,0,0,57.4,39.9);
	this.instance_37.alpha = 0.4102;

	this.instance_38 = new lib.Path_40();
	this.instance_38.setTransform(28.55,-15.3,1,1,0,0,0,11,4);

	this.instance_39 = new lib.Path_1_27();
	this.instance_39.setTransform(-17,8.85,1,1,0,0,0,10,5.5);

	this.instance_40 = new lib.Path_2_13();
	this.instance_40.setTransform(-19.9,-23.35,1,1,0,0,0,7.5,6);

	this.instance_41 = new lib.Path_3_12();
	this.instance_41.setTransform(2.05,-14.65,1,1,0,0,0,9.5,6);

	this.instance_42 = new lib.Path_4_11();
	this.instance_42.setTransform(11.75,7.4,1,1,0,0,0,12.5,5.5);

	this.instance_43 = new lib.Path_5_11();
	this.instance_43.setTransform(-24.45,-0.45,1,1,0,0,0,9,8);

	this.instance_44 = new lib.Path_6_10();
	this.instance_44.setTransform(11.15,-33.95,1,1,0,0,0,10.5,5);

	this.instance_45 = new lib.Path_7_9();
	this.instance_45.setTransform(46.7,-12.85,1,1,0,0,0,9,7.5);

	this.instance_46 = new lib.CachedBmp_137();
	this.instance_46.setTransform(-45.2,-55.15,0.5,0.5);

	this.instance_47 = new lib.Path_14();
	this.instance_47.setTransform(-102,-67);

	this.instance_48 = new lib.Path_15();
	this.instance_48.setTransform(-81,-86);

	this.instance_49 = new lib.F10over();
	this.instance_49.setTransform(-0.2,-0.2,1,1,0,0,0,-0.2,-0.2);
	this.instance_49.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_49.cache(-61,-71,122,141);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23}]},1).to({state:[{t:this.instance_49}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-102,-90.8,211,162.2);


(lib.F9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_124();
	this.instance.setTransform(-77.5,-60.15,0.5,0.5);

	this.instance_1 = new lib.Path_25();
	this.instance_1.setTransform(-44,-10.9);

	this.instance_2 = new lib.Path_1_10();
	this.instance_2.setTransform(16.95,-38.45,1,1,0,0,0,12.5,11.5);

	this.instance_3 = new lib.Path_2_2_2();
	this.instance_3.setTransform(-52.55,-36.65,1,1,0,0,0,12.5,11.5);

	this.instance_4 = new lib.Path_3_2_2();
	this.instance_4.setTransform(-46.75,5.05,1,1,0,0,0,10,9.5);

	this.instance_5 = new lib.Path_4_2_1();
	this.instance_5.setTransform(-51.6,7.5,1,1,0,0,0,12.5,11.5);

	this.instance_6 = new lib.Path_5_2_1();
	this.instance_6.setTransform(12.35,3.25,1,1,0,0,0,10,9.5);

	this.instance_7 = new lib.Path_6_1_2();
	this.instance_7.setTransform(17.9,5.7,1,1,0,0,0,12.5,11.5);

	this.instance_8 = new lib.Path_7_1_1();
	this.instance_8.setTransform(-1.2,-12.4);

	this.instance_9 = new lib.CachedBmp_123();
	this.instance_9.setTransform(-72.8,-62.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_122();
	this.instance_10.setTransform(-34.4,-64.3,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_121();
	this.instance_11.setTransform(18.35,-57,0.5,0.5);

	this.instance_12 = new lib.Path_1_8();
	this.instance_12.setTransform(49.85,-1.5,1,1,0,0,0,12,19);

	this.instance_13 = new lib.CachedBmp_120();
	this.instance_13.setTransform(-34.7,-64.55,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_119();
	this.instance_14.setTransform(-34.6,46.45,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_130();
	this.instance_15.setTransform(-94,-76.25,0.5,0.5);

	this.instance_16 = new lib.Path_3();
	this.instance_16.setTransform(-54,-23);

	this.instance_17 = new lib.Path_4_9();
	this.instance_17.setTransform(19.25,-55.95,1,1,0,0,0,14.5,14);

	this.instance_18 = new lib.Path_5_9();
	this.instance_18.setTransform(-64.55,-53.75,1,1,0,0,0,14.5,14);

	this.instance_19 = new lib.Path_6_8();
	this.instance_19.setTransform(-57.05,-3.6,1,1,0,0,0,12,11.5);

	this.instance_20 = new lib.Path_7_7();
	this.instance_20.setTransform(-63.4,-0.6,1,1,0,0,0,14.5,14);

	this.instance_21 = new lib.Path_8_6();
	this.instance_21.setTransform(14.15,-5.8,1,1,0,0,0,12,11.5);

	this.instance_22 = new lib.Path_9_5();
	this.instance_22.setTransform(20.4,-2.75,1,1,0,0,0,14.5,14);

	this.instance_23 = new lib.Path_10();
	this.instance_23.setTransform(-2,-25);

	this.instance_24 = new lib.CachedBmp_129();
	this.instance_24.setTransform(-88.4,-86.65,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_128();
	this.instance_25.setTransform(21.55,-78.35,0.5,0.5);

	this.instance_26 = new lib.Path_1_24();
	this.instance_26.setTransform(59.5,-11.95,1,1,0,0,0,14.5,22.5);

	this.instance_27 = new lib.CachedBmp_127();
	this.instance_27.setTransform(-42.5,-87.55,0.5,0.5);

	this.instance_28 = new lib.Path_17();
	this.instance_28.setTransform(-90,-115);

	this.instance_29 = new lib.Path_18();
	this.instance_29.setTransform(-80,-118);

	this.instance_30 = new lib.CachedBmp_126();
	this.instance_30.setTransform(101.45,-98.55,0.5,0.5);

	this.instance_31 = new lib.Group_1_2();
	this.instance_31.setTransform(116,-85.9,1,1,0,0,0,13,13.1);
	this.instance_31.alpha = 0.6016;

	this.instance_32 = new lib.CachedBmp_125();
	this.instance_32.setTransform(-92.25,-84.65,0.5,0.5);

	this.instance_33 = new lib.F9over();
	this.instance_33.setTransform(1.8,0,1,1,0,0,0,1.8,0);
	this.instance_33.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_33.cache(-79,-66,159,133);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15}]},1).to({state:[{t:this.instance_33}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94,-118,224,185.9);


(lib.F8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_113();
	this.instance.setTransform(-65.85,-68.3,0.5,0.5);

	this.instance_1 = new lib.Group_1_11();
	this.instance_1.setTransform(-17.25,-18.75,1,1,0,0,0,38.5,37.6);
	this.instance_1.alpha = 0.6992;

	this.instance_2 = new lib.CachedBmp_112();
	this.instance_2.setTransform(-63.85,-69.55,0.5,0.5);

	this.instance_3 = new lib.Group_0();
	this.instance_3.setTransform(41.65,0.25,1,1,0,0,0,15.7,22.8);
	this.instance_3.alpha = 0.3984;

	this.instance_4 = new lib.CachedBmp_111();
	this.instance_4.setTransform(-31.4,-70.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_110();
	this.instance_5.setTransform(-34,43.5,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_118();
	this.instance_6.setTransform(-75.4,-86.85,0.5,0.5);

	this.instance_7 = new lib.Group_1_0();
	this.instance_7.setTransform(-20,-30.25,1,1,0,0,0,43.9,43);
	this.instance_7.alpha = 0.6992;

	this.instance_8 = new lib.CachedBmp_117();
	this.instance_8.setTransform(-73.1,-88.25,0.5,0.5);

	this.instance_9 = new lib.Group_3_2();
	this.instance_9.setTransform(47.1,-8.65,1,1,0,0,0,17.7,26);
	this.instance_9.alpha = 0.3984;

	this.instance_10 = new lib.CachedBmp_116();
	this.instance_10.setTransform(-36.05,-88.85,0.5,0.5);

	this.instance_11 = new lib.Group_4();
	this.instance_11.setTransform(-113,-123);

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(-72,-122);

	this.instance_13 = new lib.CachedBmp_115();
	this.instance_13.setTransform(87.1,-84.45,0.5,0.5);

	this.instance_14 = new lib.Group_1_3();
	this.instance_14.setTransform(102.5,-71.8,1,1,0,0,0,13,13.1);
	this.instance_14.alpha = 0.6016;

	this.instance_15 = new lib.CachedBmp_114();
	this.instance_15.setTransform(-39.1,40.8,0.5,0.5);

	this.instance_16 = new lib.F8over();
	this.instance_16.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_16.cache(-68,-72,136,144);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]},1).to({state:[{t:this.instance_16}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-113,-123,228.5,193.8);


(lib.F7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_105();
	this.instance.setTransform(-68.4,-69.05,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_104();
	this.instance_1.setTransform(-31.1,-68.9,0.5,0.5);

	this.instance_2 = new lib.Group();
	this.instance_2.setTransform(41.55,-4.6,1,1,0,0,0,15.6,22.8);
	this.instance_2.alpha = 0.3984;

	this.instance_3 = new lib.CachedBmp_103();
	this.instance_3.setTransform(-32.6,-70.4,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_102();
	this.instance_4.setTransform(-37.15,47.95,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_109();
	this.instance_5.setTransform(-78.1,-87.35,0.5,0.5);

	this.instance_6 = new lib.Group_2_9();
	this.instance_6.setTransform(46.25,-14.5,1,1,0,0,0,17.6,25.8);
	this.instance_6.alpha = 0.3984;

	this.instance_7 = new lib.CachedBmp_108();
	this.instance_7.setTransform(-37.65,-89,0.5,0.5);

	this.instance_8 = new lib.Group_3();
	this.instance_8.setTransform(-94.95,-100.8);

	this.instance_9 = new lib.Path_5();
	this.instance_9.setTransform(-73.95,-124.8);

	this.instance_10 = new lib.CachedBmp_107();
	this.instance_10.setTransform(89.5,-93.05,0.5,0.5);

	this.instance_11 = new lib.Group_1_6();
	this.instance_11.setTransform(104.05,-80.4,1,1,0,0,0,13,13.1);
	this.instance_11.alpha = 0.6016;

	this.instance_12 = new lib.CachedBmp_106();
	this.instance_12.setTransform(-42.8,45,0.5,0.5);

	this.instance_13 = new lib.F7over();
	this.instance_13.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_13.cache(-70,-72,141,145);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]},1).to({state:[{t:this.instance_13}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94.9,-124.8,212,195.3);


(lib.F6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_28();
	this.instance.setTransform(0.05,-30.4,1,1,0,0,0,14.1,25.6);
	this.instance.alpha = 0.3984;

	this.instance_1 = new lib.CachedBmp_98();
	this.instance_1.setTransform(-64.45,-70.45,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_97();
	this.instance_2.setTransform(-36.75,-60.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_96();
	this.instance_3.setTransform(-17.1,47.9,0.5,0.5);

	this.instance_4 = new lib.Path_38();
	this.instance_4.setTransform(0.3,-44.3,1,1,0,0,0,16,29.2);
	this.instance_4.alpha = 0.3984;

	this.instance_5 = new lib.CachedBmp_101();
	this.instance_5.setTransform(-72.7,-89.9,0.5,0.5);

	this.instance_6 = new lib.Path_8();
	this.instance_6.setTransform(-110,-126);

	this.instance_7 = new lib.Path_9();
	this.instance_7.setTransform(-79,-116);

	this.instance_8 = new lib.CachedBmp_100();
	this.instance_8.setTransform(93.6,-82.55,0.5,0.5);

	this.instance_9 = new lib.Group_1_4();
	this.instance_9.setTransform(108.15,-69.9,1,1,0,0,0,13,13.1);
	this.instance_9.alpha = 0.6016;

	this.instance_10 = new lib.CachedBmp_99();
	this.instance_10.setTransform(-19.2,44.8,0.5,0.5);

	this.instance_11 = new lib.F6over();
	this.instance_11.setTransform(-1.1,0,1,1,0,0,0,-1.1,0);
	this.instance_11.filters = [new cjs.ColorFilter(0.4, 0.4, 0.4, 1, 138, 147, 130.8, 0)];
	this.instance_11.cache(-66,-72,131,145);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).to({state:[{t:this.instance_11}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-126,231.2,196.4);


(lib.F5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_92();
	this.instance.setTransform(-72.55,-77.75,0.5,0.5);

	this.instance_1 = new lib.Path_1_6();
	this.instance_1.setTransform(-29.95,-18.25,1,1,0,0,0,27.8,33.1);
	this.instance_1.alpha = 0.3008;

	this.instance_2 = new lib.CachedBmp_91();
	this.instance_2.setTransform(-71,-66.35,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_90();
	this.instance_3.setTransform(-38.25,-78.3,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_89();
	this.instance_4.setTransform(-36.45,61.25,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_95();
	this.instance_5.setTransform(100.85,-60.7,0.5,0.5);

	this.instance_6 = new lib.Group_1_7();
	this.instance_6.setTransform(115.4,-48.05,1,1,0,0,0,13,13.1);
	this.instance_6.alpha = 0.6016;

	this.instance_7 = new lib.CachedBmp_94();
	this.instance_7.setTransform(-84.7,-79.1,0.5,0.5);

	this.instance_8 = new lib.Path_3_11();
	this.instance_8.setTransform(-36.05,-12.2,1,1,0,0,0,31.8,37.9);
	this.instance_8.alpha = 0.3008;

	this.instance_9 = new lib.CachedBmp_93();
	this.instance_9.setTransform(-82.95,-80.95,0.5,0.5);

	this.instance_10 = new lib.Path_16();
	this.instance_10.setTransform(-123,-86);

	this.instance_11 = new lib.Path_17_1();
	this.instance_11.setTransform(-79,-89);

	this.instance_12 = new lib.F5over();
	this.instance_12.setTransform(-0.4,-0.1,1,1,0,0,0,-0.4,-0.1);
	this.instance_12.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_12.cache(-74,-80,148,161);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]},1).to({state:[{t:this.instance_12}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-123,-89,251.5,187.1);


(lib.F4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_83();
	this.instance.setTransform(-71.75,-68.35,0.5,0.5);

	this.instance_1 = new lib.Path_1_2_1();
	this.instance_1.setTransform(-2.05,-27.25);

	this.instance_2 = new lib.Path_2_1();
	this.instance_2.setTransform(5.85,-35.3);

	this.instance_3 = new lib.Path_3_2();
	this.instance_3.setTransform(-6.8,-36);

	this.instance_4 = new lib.Path_4_1();
	this.instance_4.setTransform(-7.6,-9.2);

	this.instance_5 = new lib.Path_5_2();
	this.instance_5.setTransform(2.05,-8.7);

	this.instance_6 = new lib.Path_6_2();
	this.instance_6.setTransform(-2.8,-17.75);

	this.instance_7 = new lib.Path_7_1();
	this.instance_7.setTransform(-20.25,8.65);

	this.instance_8 = new lib.Path_8_2();
	this.instance_8.setTransform(-16.65,1.05);

	this.instance_9 = new lib.Path_9_2();
	this.instance_9.setTransform(-8.6,2.15);

	this.instance_10 = new lib.Path_10_0_2();
	this.instance_10.setTransform(-44.75,0.35);

	this.instance_11 = new lib.Path_11_1();
	this.instance_11.setTransform(-37.4,-1.95);

	this.instance_12 = new lib.Path_12_1();
	this.instance_12.setTransform(-34.7,4.85);

	this.instance_13 = new lib.Path_13_1();
	this.instance_13.setTransform(-49.6,-27.25);

	this.instance_14 = new lib.Path_14_2();
	this.instance_14.setTransform(-49.6,-6.25);

	this.instance_15 = new lib.Path_15_2();
	this.instance_15.setTransform(-47.35,-16.35);

	this.instance_16 = new lib.Path_16_2();
	this.instance_16.setTransform(-37.65,-40.2);

	this.instance_17 = new lib.Path_17_3();
	this.instance_17.setTransform(-46.25,-43.9);

	this.instance_18 = new lib.Path_18_2();
	this.instance_18.setTransform(-43.9,-35.05);

	this.instance_19 = new lib.Path_19_1();
	this.instance_19.setTransform(-18.05,-49.5);

	this.instance_20 = new lib.Path_20_1();
	this.instance_20.setTransform(-16.05,-41.2);

	this.instance_21 = new lib.Path_21_1();
	this.instance_21.setTransform(-27.95,-49.5);

	this.instance_22 = new lib.CachedBmp_82();
	this.instance_22.setTransform(-34.55,-31.4,0.5,0.5);

	this.instance_23 = new lib.Path_23();
	this.instance_23.setTransform(-23.5,-17.8,1,1,0,0,0,24.9,29.8);
	this.instance_23.alpha = 0.5;

	this.instance_24 = new lib.CachedBmp_81();
	this.instance_24.setTransform(-68.3,-68.8,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_80();
	this.instance_25.setTransform(-27,-69.3,0.5,0.5);

	this.instance_26 = new lib.Path_1_1_1();
	this.instance_26.setTransform(28.95,6.2,1,1,0,0,0,28.2,12.8);
	this.instance_26.alpha = 0.1016;

	this.instance_27 = new lib.CachedBmp_79();
	this.instance_27.setTransform(-26.95,-71.6,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_78();
	this.instance_28.setTransform(-15.4,51.9,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_88();
	this.instance_29.setTransform(92.25,-70.2,0.5,0.5);

	this.instance_30 = new lib.Group_1_8();
	this.instance_30.setTransform(106.8,-57.55,1,1,0,0,0,13,13.1);
	this.instance_30.alpha = 0.6016;

	this.instance_31 = new lib.CachedBmp_87();
	this.instance_31.setTransform(-86,-71.3,0.5,0.5);

	this.instance_32 = new lib.Path_1();
	this.instance_32.setTransform(-4,-23);

	this.instance_33 = new lib.Path_2();
	this.instance_33.setTransform(5,-33);

	this.instance_34 = new lib.Path_3_1();
	this.instance_34.setTransform(-10,-34);

	this.instance_35 = new lib.Path_4();
	this.instance_35.setTransform(-11,-2);

	this.instance_36 = new lib.Path_5_1();
	this.instance_36.setTransform(0,-2);

	this.instance_37 = new lib.Path_6_1();
	this.instance_37.setTransform(-5,-12);

	this.instance_38 = new lib.Path_7();
	this.instance_38.setTransform(-26,19);

	this.instance_39 = new lib.Path_8_1();
	this.instance_39.setTransform(-22,10);

	this.instance_40 = new lib.Path_9_1();
	this.instance_40.setTransform(-12,11);

	this.instance_41 = new lib.Path_10_1();
	this.instance_41.setTransform(-55,9);

	this.instance_42 = new lib.Path_11();
	this.instance_42.setTransform(-46,6);

	this.instance_43 = new lib.Path_12();
	this.instance_43.setTransform(-43,14);

	this.instance_44 = new lib.Path_13();
	this.instance_44.setTransform(-60,-23);

	this.instance_45 = new lib.Path_14_1();
	this.instance_45.setTransform(-60,1);

	this.instance_46 = new lib.Path_15_1();
	this.instance_46.setTransform(-58,-10);

	this.instance_47 = new lib.Path_16_1();
	this.instance_47.setTransform(-46,-38);

	this.instance_48 = new lib.Path_17_2();
	this.instance_48.setTransform(-56,-43);

	this.instance_49 = new lib.Path_18_1();
	this.instance_49.setTransform(-54,-32);

	this.instance_50 = new lib.Path_19();
	this.instance_50.setTransform(-23,-49);

	this.instance_51 = new lib.Path_20();
	this.instance_51.setTransform(-21,-40);

	this.instance_52 = new lib.Path_21();
	this.instance_52.setTransform(-35,-49);

	this.instance_53 = new lib.CachedBmp_86();
	this.instance_53.setTransform(-42.35,-27.9,0.5,0.5);

	this.instance_54 = new lib.Path_23_1();
	this.instance_54.setTransform(-29.4,-12,1,1,0,0,0,29.3,35);
	this.instance_54.alpha = 0.5;

	this.instance_55 = new lib.CachedBmp_85();
	this.instance_55.setTransform(-82.1,-72.35,0.5,0.5);

	this.instance_56 = new lib.Path_27_1();
	this.instance_56.setTransform(32.15,16.25,1,1,0,0,0,33.1,15.1);
	this.instance_56.alpha = 0.1016;

	this.instance_57 = new lib.CachedBmp_84();
	this.instance_57.setTransform(-33.45,-75.15,0.5,0.5);

	this.instance_58 = new lib.Path_29();
	this.instance_58.setTransform(-119,-47);

	this.instance_59 = new lib.Path_31();
	this.instance_59.setTransform(-71,-110);

	this.instance_60 = new lib.F4over();
	this.instance_60.setTransform(0.1,0,1,1,0,0,0,0.1,0);
	this.instance_60.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_60.cache(-74,-74,148,148);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29}]},1).to({state:[{t:this.instance_60}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-119,-110,239,202.9);


(lib.F3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_72();
	this.instance.setTransform(-53.85,-40.7,0.5,0.5);

	this.instance_1 = new lib.Path_34();
	this.instance_1.setTransform(1.5,-8.6,1,1,0,0,0,18.8,36.1);
	this.instance_1.alpha = 0.3008;

	this.instance_2 = new lib.Path_1_0_3();
	this.instance_2.setTransform(-38.3,-9.5,1,1,0,0,0,18.7,35.7);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.CachedBmp_71();
	this.instance_3.setTransform(-64.7,-78.7,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_70();
	this.instance_4.setTransform(-31.45,-75.7,0.5,0.5);

	this.instance_5 = new lib.Path_1_21();
	this.instance_5.setTransform(45.95,-16.05,1,1,0,0,0,9.1,28.8);
	this.instance_5.alpha = 0.2617;

	this.instance_6 = new lib.CachedBmp_69();
	this.instance_6.setTransform(-30.95,-77,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_68();
	this.instance_7.setTransform(-19.35,60.4,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_77();
	this.instance_8.setTransform(-65.35,-40.25,0.5,0.5);

	this.instance_9 = new lib.Path_39();
	this.instance_9.setTransform(0.3,-3.1,1,1,0,0,0,21.7,41.8);
	this.instance_9.alpha = 0.3008;

	this.instance_10 = new lib.Path_1_26();
	this.instance_10.setTransform(-45.65,-4.05,1,1,0,0,0,21.7,41.4);
	this.instance_10.alpha = 0.3008;

	this.instance_11 = new lib.CachedBmp_76();
	this.instance_11.setTransform(-76.25,-84.2,0.5,0.5);

	this.instance_12 = new lib.Path_6_9();
	this.instance_12.setTransform(51.75,-11.75,1,1,0,0,0,10.5,33.3);
	this.instance_12.alpha = 0.2617;

	this.instance_13 = new lib.CachedBmp_75();
	this.instance_13.setTransform(-37.2,-82.25,0.5,0.5);

	this.instance_14 = new lib.Path_8_3();
	this.instance_14.setTransform(-114,-38);

	this.instance_15 = new lib.Path_9_3();
	this.instance_15.setTransform(-75,-120);

	this.instance_16 = new lib.CachedBmp_74();
	this.instance_16.setTransform(99.15,-70.65,0.5,0.5);

	this.instance_17 = new lib.Group_1_5();
	this.instance_17.setTransform(113.7,-58,1,1,0,0,0,13,13.1);
	this.instance_17.alpha = 0.6016;

	this.instance_18 = new lib.CachedBmp_73();
	this.instance_18.setTransform(-23.8,76.75,0.5,0.5);

	this.instance_19 = new lib.F3over();
	this.instance_19.setTransform(0.2,0,1,1,0,0,0,0.2,0);
	this.instance_19.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_19.cache(-67,-81,134,162);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8}]},1).to({state:[{t:this.instance_19}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114,-120,240.8,217.8);


(lib.F2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"normal":0,"click":1,"over":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_61();
	this.instance.setTransform(-64.95,-72.95,0.5,0.5);

	this.instance_1 = new lib.Path_22();
	this.instance_1.setTransform(-31.55,-17.65,1,1,0,0,0,3.8,15.5);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(-18.8,-65.05,1,1,0,0,0,2.7,6.8);
	this.instance_2.alpha = 0.1484;

	this.instance_3 = new lib.Path_2_0_2();
	this.instance_3.setTransform(-5.15,-17.45,1,1,0,0,0,8.6,16.1);
	this.instance_3.alpha = 0.1484;

	this.instance_4 = new lib.Path_3_0_2();
	this.instance_4.setTransform(-50.95,-8.35);

	this.instance_5 = new lib.Path_4_0_3();
	this.instance_5.setTransform(-8.1,-8.8);

	this.instance_6 = new lib.Path_5_0_3();
	this.instance_6.setTransform(-24.8,-42.05);

	this.instance_7 = new lib.CachedBmp_60();
	this.instance_7.setTransform(-63,-72.45,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_59();
	this.instance_8.setTransform(-27.2,-74.25,0.5,0.5);

	this.instance_9 = new lib.Path_0_2();
	this.instance_9.setTransform(46.3,-20.85,1,1,0,0,0,8.8,27.9);
	this.instance_9.alpha = 0.2617;

	this.instance_10 = new lib.Path_1_3();
	this.instance_10.setTransform(45.55,-65.55,1,1,0,0,0,1.5,8);

	this.instance_11 = new lib.CachedBmp_58();
	this.instance_11.setTransform(-24.45,-74.7,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_57();
	this.instance_12.setTransform(-17.3,54.7,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_67();
	this.instance_13.setTransform(-76,-75.7,0.5,0.5);

	this.instance_14 = new lib.Path_36();
	this.instance_14.setTransform(-37.85,-12.25,1,1,0,0,0,4.2,17.8);
	this.instance_14.alpha = 0.1484;

	this.instance_15 = new lib.Path_1_23();
	this.instance_15.setTransform(-7.4,-12.05,1,1,0,0,0,9.9,18.4);
	this.instance_15.alpha = 0.1484;

	this.instance_16 = new lib.Path_2_2();
	this.instance_16.setTransform(-60,-2);

	this.instance_17 = new lib.Path_3_3();
	this.instance_17.setTransform(-11,-3);

	this.instance_18 = new lib.Path_4_2();
	this.instance_18.setTransform(-30,-41);

	this.instance_19 = new lib.CachedBmp_66();
	this.instance_19.setTransform(-73.8,-76.45,0.5,0.5);

	this.instance_20 = new lib.Path_8_5();
	this.instance_20.setTransform(51.85,-15.95,1,1,0,0,0,10.2,32);
	this.instance_20.alpha = 0.2617;

	this.instance_21 = new lib.CachedBmp_65();
	this.instance_21.setTransform(-29.4,-66.65,0.5,0.5);

	this.instance_22 = new lib.Group_2();
	this.instance_22.setTransform(-97,-71);

	this.instance_23 = new lib.Group_3_1();
	this.instance_23.setTransform(-71,-109);

	this.instance_24 = new lib.CachedBmp_64();
	this.instance_24.setTransform(83.85,-76.45,0.5,0.5);

	this.instance_25 = new lib.Group_1_1();
	this.instance_25.setTransform(98.4,-63.8,1,1,0,0,0,13,13.1);
	this.instance_25.alpha = 0.6016;

	this.instance_26 = new lib.Path_10_5();
	this.instance_26.setTransform(-23.1,-66.8,1,1,0,0,0,3.1,7.7);
	this.instance_26.alpha = 0.1484;

	this.instance_27 = new lib.CachedBmp_63();
	this.instance_27.setTransform(-33.35,-75.2,0.5,0.5);

	this.instance_28 = new lib.Path_12_3();
	this.instance_28.setTransform(51.2,-67.5,1,1,0,0,0,2,9);

	this.instance_29 = new lib.CachedBmp_62();
	this.instance_29.setTransform(-21.35,-77.7,0.5,0.5);

	this.instance_30 = new lib.F2over();
	this.instance_30.setTransform(-0.1,-0.8,1,1,0,0,0,-0.1,-0.8);
	this.instance_30.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 115, 122.5, 109, 0)];
	this.instance_30.cache(-67,-77,134,153);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13}]},1).to({state:[{t:this.instance_30}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-109,208.5,202.3);


// stage content:
(lib.InteractiveReoresentationBakapaim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		// הגדרת משתנים בסיסים לתפעול
		var self = this;
		var frequency = 24;
		var whaToStop = ["S1","S2","S3","S4","About","inst","popAll","F1","F2","F3","F4","F5","F6","F7","F8","F9","F10"];
		var seasonOrder = [1,3,4,4,4,1,3,2,4,1];
		var lockSeason = 0;
		var lockFruit = 0;
		
		// עצור את כל הסימבולים שהוגדרו במערך
		for (i=0;i<whaToStop.length;i++){
			self[whaToStop[i]].stop();
		}
		
		// הסתר מסך הודות
		self.aboutP.visible = false;
		
		//הפעל מעבר עכבר בבמה
		stage.enableMouseOver(frequency);
		
		// ייצור ליסנרים לפירות והעונות במקרה של עכבר בחוץ 
		for(i=1;i<=10;i++){
			this["F"+i].addEventListener("mouseout", switchOff.bind(this));
			if(i<=4){
				this["S"+i].addEventListener("mouseout", switchOff.bind(this));
			}
		}
		
		// מתאים בין פירות שפתוחים במסך אל העונה
		function matchFruteToSeason(){
			for(i=1;i<=10;i++){
				if(seasonOrder[i-1] == lockSeason){
					self["F"+i].gotoAndStop("normal");
				}
			}
		}
		
		//הפעל סינון על פירות
		function switchFruit(num){
			mouseSyle("F"+num);
			if(self["F"+num].getCurrentLabel()!="over"){
				for(i=1;i<=10;i++){
					if(i != num){
						self["F"+i].gotoAndStop("over");
					}
				}
				for(i=1;i<=4;i++){
					if(seasonOrder[num-1] != i){
						self["S"+i].gotoAndStop("over");
					}
				}
			}		
		}
		function clickFruit(num){
			if(self["F"+num].getCurrentLabel()=="normal"){
				lockFruit = num;
				self["F"+num].gotoAndStop("click");
				self.popAll.gotoAndPlay(1);
				self.popAll.pop.gotoAndStop("F"+num);
				instMode("click");
			}
			else{
				if(self["F"+num].getCurrentLabel()=="click"){
					lockFruit = 0;
					self["F"+num].gotoAndStop("normal");
					self.popAll.gotoAndPlay(12);
					instMode("normal");
				}
			}
		}
		
		//הפעל סינון על עונות
		function switchSeason(num){
			mouseSyle("S"+num);
			if(self["S"+num].getCurrentLabel()!="over"){
			for(i=0;i<seasonOrder.length;i++){
				if(num != seasonOrder[i]){
					self["F"+(i+1)].gotoAndStop("over");
				}
			}
			for(i=1;i<=4;i++){
				if(num != i){
					self["S"+i].gotoAndStop("over");
				}
			}
			}	
		}
		function clickSeason(num){
			if(self["S"+num].getCurrentLabel()=="normal"){
				lockSeason = num;
				self["S"+num].gotoAndStop("click");
				instMode("click");
			}
			else{
				if(self["S"+num].getCurrentLabel()=="click"){
					lockSeason = 0;
					self["S"+num].gotoAndStop("normal");
					instMode("normal");
				}
			}
		}
		
		//פונקציות בטל סינון
		function switchOff(){ 
			mouseSyle("");
			if(lockFruit == 0 && lockSeason == 0){
				switchFruitOff();
				switchSeasonOff();
			}
			else{
				if (lockSeason!=0 && lockFruit ==0){
					matchFruteToSeason();
				}
			}
		}
		
		function switchFruitOff()
		{
			if(lockSeason == 0){
					for(i=1;i<=10;i++){
						self["F"+i].gotoAndStop("normal");
				}
			}
			else{
					matchFruteToSeason();
				}
		}
		
		function switchSeasonOff(){
				for(i=1;i<=4;i++){
						self["S"+i].gotoAndStop("normal");
				}
		}
		
		// פונקציות הפעלה של כפתור אודות
		this.About.addEventListener("mouseover", aboutOver.bind(this));
		this.About.addEventListener("mouseout", aboutOut.bind(this));
		this.About.addEventListener("click", aboutClick.bind(this));
		
		this.aboutP.aboutC.addEventListener("click", aboutClose.bind(this));
		this.aboutP.aboutC.addEventListener("mouseover", aboutOverClose.bind(this));
		this.aboutP.aboutC.addEventListener("mouseout", aboutOut.bind(this));
		
		function aboutOver(){
			mouseSyle("About");
		}
		
		function aboutOverClose(){
			mouseSyle("aboutP");
		}
		
		function aboutOut(){
			mouseSyle("");
		}
		function aboutClick(){
			self.About.gotoAndStop("over");
			self.aboutP.visible = true;
		}
		function aboutClose()
		{
			self.aboutP.visible = false;
			self.About.gotoAndStop("normal");
		}
		
		// בודק על איזה אובייקט אני עובר עם העכבר ומתאים את העכבר אליו
		function mouseSyle(objectName){
			console.log("arave");
			if (objectName == ""){
				self.stage.cursor = "auto";
			}
			else{
				if(self[objectName].getCurrentLabel()=="over"){
					self.stage.cursor = "not-allowed";
				}
				else{
					self.stage.cursor = "pointer";
				}
			}
		}
		// אם לחצנו אז תשנה את ההוראה
		function instMode(mode){
			self.inst.gotoAndStop(mode);
		}
		
		// כל הפונקציות וליסנרים של עונה 1 - קיץ
		this.S1.addEventListener("mouseover", mouseOverS1.bind(this));
		this.S1.addEventListener("click", clickS1.bind(this));
		
		function mouseOverS1(){
			switchSeason(1);
		}
		function clickS1(){
			clickSeason(1);
		}
		
		// כל הפונקציות וליסנרים של עונה 2 - חורף
		this.S2.addEventListener("mouseover", mouseOverS2.bind(this));
		this.S2.addEventListener("click", clickS2.bind(this));
		
		function mouseOverS2(){
			switchSeason(2);
		}
		function clickS2(){
			clickSeason(2);
		}
		
		// כל הפונקציות וליסנרים של עונה 3 - אביב
		this.S3.addEventListener("mouseover", mouseOverS3.bind(this));
		this.S3.addEventListener("click", clickS3.bind(this));
		
		function mouseOverS3(){
			switchSeason(3);
		}
		function clickS3(){
			clickSeason(3);
		}
		
		// כל הפונקציות וליסנרים של עונה 4 - סתיו
		this.S4.addEventListener("mouseover", mouseOverS4.bind(this));
		this.S4.addEventListener("click", clickS4.bind(this));
		
		function mouseOverS4(){
			switchSeason(4);
		}
		function clickS4(){
			clickSeason(4);
		}
		
		// כל הפונקציות וליסנרים של פרי 1 - אבטיח
		this.F1.addEventListener("mouseover", mouseOverF1.bind(this));
		this.F1.addEventListener("click", clickF1.bind(this));
		
		function mouseOverF1(){
			switchFruit(1);
		}
		function clickF1(){
			clickFruit(1);
		}
		
		// כל הפונקציות וליסנרים של פרי 2 - שסק
		this.F2.addEventListener("mouseover", mouseOverF2.bind(this));
		this.F2.addEventListener("click", clickF2.bind(this));
		
		function mouseOverF2(){
			switchFruit(2);
		}
		function clickF2(){
			clickFruit(2);
		}
		
		// כל הפונקציות וליסנרים של פרי 3 - רימון
		this.F3.addEventListener("mouseover", mouseOverF3.bind(this));
		this.F3.addEventListener("click", clickF3.bind(this));
		
		function mouseOverF3(){
			switchFruit(3);
		}
		function clickF3(){
			clickFruit(3);
		}
		
		// כל הפונקציות וליסנרים של פרי 4 - קיווי
		this.F4.addEventListener("mouseover", mouseOverF4.bind(this));
		this.F4.addEventListener("click", clickF4.bind(this));
		
		function mouseOverF4(){
			switchFruit(4);
		}
		function clickF4(){
			clickFruit(4);
		}
		
		// כל הפונקציות וליסנרים של פרי 5 - תות
		this.F5.addEventListener("mouseover", mouseOverF5.bind(this));
		this.F5.addEventListener("click", clickF5.bind(this));
		
		function mouseOverF5(){
			switchFruit(5);
		}
		function clickF5(){
			clickFruit(5);
		}
		
		// כל הפונקציות וליסנרים של פרי 6 - ליצ'י
		this.F6.addEventListener("mouseover", mouseOverF6.bind(this));
		this.F6.addEventListener("click", clickF6.bind(this));
		
		function mouseOverF6(){
			switchFruit(6);
		}
		function clickF6(){
			clickFruit(6);
		}
		
		// כל הפונקציות וליסנרים של פרי 7 - פסיפלורה
		this.F7.addEventListener("mouseover", mouseOverF7.bind(this));
		this.F7.addEventListener("click", clickF7.bind(this));
		
		function mouseOverF7(){
			switchFruit(7);
		}
		function clickF7(){
			clickFruit(7);
		}
		
		// כל הפונקציות וליסנרים של פרי 8 - אשקולית
		this.F8.addEventListener("mouseover", mouseOverF8.bind(this));
		this.F8.addEventListener("click", clickF8.bind(this));
		
		function mouseOverF8(){
			switchFruit(8);
		}
		function clickF8(){
			clickFruit(8);
		}
		
		// כל הפונקציות וליסנרים של פרי 9 - אפרסמון
		this.F9.addEventListener("mouseover", mouseOverF9.bind(this));
		this.F9.addEventListener("click", clickF9.bind(this));
		
		function mouseOverF9(){
			switchFruit(9);
		}
		function clickF9(){
			clickFruit(9);
		}
		
		// כל הפונקציות וליסנרים של פרי 10 - תמר
		this.F10.addEventListener("mouseover", mouseOverF10.bind(this));
		this.F10.addEventListener("click", clickF10.bind(this));
		
		function mouseOverF10(){
			switchFruit(10);
		}
		function clickF10(){
			clickFruit(10);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// PopUp
	this.popAll = new lib.popAll();
	this.popAll.name = "popAll";
	this.popAll.setTransform(0,0.95);

	this.timeline.addTween(cjs.Tween.get(this.popAll).wait(1));

	// about
	this.About = new lib.About();
	this.About.name = "About";
	this.About.setTransform(78.8,53.7,1,1,0,0,0,-0.2,0);

	this.aboutP = new lib.aboutPop();
	this.aboutP.name = "aboutP";
	this.aboutP.setTransform(640,357);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.aboutP},{t:this.About}]}).wait(1));

	// UI
	this.S4 = new lib.S4();
	this.S4.name = "S4";
	this.S4.setTransform(316.1,149.05,1,1,0,0,0,-0.2,0);

	this.S3 = new lib.S3();
	this.S3.name = "S3";
	this.S3.setTransform(531.9,149.05,1,1,0,0,0,-0.2,0);

	this.S2 = new lib.S2();
	this.S2.name = "S2";
	this.S2.setTransform(747.65,149.05,1,1,0,0,0,-0.2,0);

	this.S1 = new lib.S1();
	this.S1.name = "S1";
	this.S1.setTransform(963.4,149.05,1,1,0,0,0,-0.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.S1},{t:this.S2},{t:this.S3},{t:this.S4}]}).wait(1));

	// Fruts
	this.F10 = new lib.F10();
	this.F10.name = "F10";
	this.F10.setTransform(1043.4,478.65,1,1,0,0,0,-0.2,-0.2);

	this.F9 = new lib.F9();
	this.F9.name = "F9";
	this.F9.setTransform(840.1,484.1,1,1,0,0,0,1.8,0);

	this.F8 = new lib.F8();
	this.F8.name = "F8";
	this.F8.setTransform(624.9,477.6);

	this.F7 = new lib.F7();
	this.F7.name = "F7";
	this.F7.setTransform(431.15,475.7);

	this.F6 = new lib.F6();
	this.F6.name = "F6";
	this.F6.setTransform(231.6,473.2,1,1,0,0,0,-1.1,0);

	this.F5 = new lib.F5();
	this.F5.name = "F5";
	this.F5.setTransform(1042.35,291.15,1,1,0,0,0,-0.4,-0.1);

	this.F4 = new lib.F4();
	this.F4.name = "F4";
	this.F4.setTransform(838.4,300.85,1,1,0,0,0,0.1,0);

	this.F3 = new lib.F3();
	this.F3.name = "F3";
	this.F3.setTransform(625.05,292.35,1,1,0,0,0,0.2,0);

	this.F2 = new lib.F2();
	this.F2.name = "F2";
	this.F2.setTransform(431,297.5,1,1,0,0,0,-0.1,-0.8);

	this.F1 = new lib.F1();
	this.F1.name = "F1";
	this.F1.setTransform(232.75,296.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.F1},{t:this.F2},{t:this.F3},{t:this.F4},{t:this.F5},{t:this.F6},{t:this.F7},{t:this.F8},{t:this.F9},{t:this.F10}]}).wait(1));

	// Back
	this.inst = new lib.instructions();
	this.inst.name = "inst";
	this.inst.setTransform(639.95,84.5);

	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(500.5,25.4,0.5,0.5);

	this.instance_1 = new lib.Path_10_4();
	this.instance_1.setTransform(640,360,1,1,0,0,0,640,360);
	this.instance_1.alpha = 0.1016;

	this.instance_2 = new lib.Path_35();
	this.instance_2.setTransform(640.4,360,1,1,0,0,0,640,360);
	this.instance_2.alpha = 0.1016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.inst}]}).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("Ehljg5zMDLHAAAMAAABznMjLHAAAg");
	this.shape.setTransform(640,360);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhljA50MAAAhznMDLHAAAMAAABzng");
	this.shape_1.setTransform(640,360);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(622.1,349,701.9,521.4);
// library properties:
lib.properties = {
	id: 'D41D456C396E6C4B8E5D5480FB58A48B',
	width: 1280,
	height: 720,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/InteractiveReoresentationBakapaim_atlas_1.png?1653809371455", id:"InteractiveReoresentationBakapaim_atlas_1"},
		{src:"images/InteractiveReoresentationBakapaim_atlas_2.png?1653809371456", id:"InteractiveReoresentationBakapaim_atlas_2"},
		{src:"images/InteractiveReoresentationBakapaim_atlas_3.png?1653809371457", id:"InteractiveReoresentationBakapaim_atlas_3"},
		{src:"images/InteractiveReoresentationBakapaim_atlas_4.png?1653809371464", id:"InteractiveReoresentationBakapaim_atlas_4"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D41D456C396E6C4B8E5D5480FB58A48B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;